shader_type canvas_item;
// Perspective ground plane ("mode 7") seen from a plane flying level.
uniform sampler2D sea_tex : repeat_enable, filter_linear_mipmap;
uniform sampler2D land_tex : repeat_enable, filter_linear_mipmap;
uniform sampler2D city_tex : repeat_enable, filter_linear_mipmap;
uniform vec2 rect_size = vec2(1800.0, 1240.0);
uniform float hor = 550.0;
uniform float cx = 900.0;
uniform float focal = 640.0;
uniform float cam_h = 220.0;
uniform vec2 cam = vec2(0.0, 0.0);
uniform vec2 dir = vec2(0.0, 1.0);   // camera forward on the ground (x, z)
uniform float land_start = 1e9;
uniform float land_end = 1e9;
uniform float city_start = 1e9;
uniform float city_end = 1e9;
uniform float tile = 900.0;
uniform vec3 fog_col = vec3(0.78, 0.62, 0.45);

vec3 mirrored(sampler2D t, vec2 uv) {
	vec2 m = abs(mod(uv, 2.0) - 1.0);
	return texture(t, m).rgb;
}

void fragment() {
	vec2 p = UV * rect_size;
	float dy = p.y - hor;
	if (dy <= 0.6) {
		COLOR = vec4(0.0);
	} else {
		float dz = cam_h * focal / dy;
		float lat = (p.x - cx) * dz / focal;
		vec2 rgt = vec2(dir.y, -dir.x);
		vec2 g = cam + dir * dz + rgt * lat;
		float gx = g.x;
		float gz = g.y;
		vec2 uv = vec2(gx, gz) / tile;
		vec3 c = mirrored(sea_tex, uv * 0.7);
		float land = smoothstep(land_start - 40.0, land_start + 40.0, gz) * (1.0 - smoothstep(land_end - 40.0, land_end + 40.0, gz));
		float city = smoothstep(city_start - 80.0, city_start + 80.0, gz) * (1.0 - smoothstep(city_end - 80.0, city_end + 80.0, gz));
		c = mix(c, mirrored(land_tex, uv), land);
		c = mix(c, mirrored(city_tex, uv * 1.3), city);
		float fog = clamp(dz / 3200.0, 0.0, 1.0);
		c = mix(c * vec3(1.05, 0.97, 0.88), fog_col, pow(fog, 0.8) * 0.85);
		float edge = smoothstep(0.6, 14.0, dy);
		COLOR = vec4(c, edge);
	}
}
