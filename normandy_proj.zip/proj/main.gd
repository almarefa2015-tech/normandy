extends Control
# Normandy 1944 — bunker defence chapter (landscape)

const W := 1280.0
const H := 720.0
const HOR := 288.0          # horizon line on screen (matches bg.jpg)
const NEAR := 216.0         # pixels below horizon at world distance 1
const WAVES := 5
const PKG := "com.khaled.ww2"
const SAVE := "user://save.cfg"

class Ent:
	var kind := ""          # boat / sold / tank
	var x := 0.0            # lateral -1..1
	var z := 40.0           # world distance (smaller = closer)
	var hp := 1.0
	var state := ""
	var t := 0.0
	var cargo := 0
	var has_tank := false
	var cd := 0.0
	var flip := false
	var ph := 0.0
	var tx := 0.0
	var zstop := 1.2
	var spd := 0.6
	var unload_t := 0.0
	var smoke_t := 0.0

var T := {}
var SND := {}
var players: Array = []
var font: Font

var ents: Array = []
var fx: Array = []        # fire flashes (additive)
var smoke: Array = []     # dark smoke (normal blend)
var puffs: Array = []     # bullet impacts
var tracers: Array = []
var nades: Array = []
var crates: Array = []
var planes: Array = []    # supply planes {x, y, drops:[x...], types:[...]}
var pending: Array = []   # delayed hits {t, pos, dmg, size}

var level := 1
var wave := 0
var health := 100.0
var mg_ammo := 300
var at_ammo := 4
var weapon := "mg"
var at_reload := 0.0
var mg_cd := 0.0
var running := false
var spawn_q: Array = []
var wave_t := 0.0
var wave_units := 0
var wave_kills := 0
var dropped := false
var between := -1.0
var shake := 0.0
var recoil := 0.0
var muzzle := 0.0
var hurt_a := 0.0
var aim := Vector2(W * 0.5, H * 0.42)
var firing := false
var fire_idx := -1
var aim_idx := -1
var best := 1
var rated := false
var rate_shown := false
var no_ammo_t := 0.0
var AR := false
var belt := BELT
var mg_reload := 0.0
var joy_idx := -1
var joy := Vector2.ZERO
var cannon_view := 0.0
var cannon_shot := -1.0

var world: Node2D
var fxl: Node2D
var gun: Node2D
var gunfx: Node2D
var hud: Node2D
var retl: Node2D
var flash: ColorRect
var top_l: Label
var banner: Label
var info_l: Label
var menu: Control
var mapc: Control
var intro: Control
var intro_vp: VideoStreamPlayer
var pins: Control
var pause_p: Control
var end_p: Control
var end_title: Label
var end_sub: Label
var end_next: Button
var rate_p: Control
var start_btn: Button
var lvl_l: Label

# battles on the campaign map: image pixel position on map.jpg (1376x768), label offset side
const BATTLES := [
	["بولندا", "Poland", 1939, Vector2(600, 255), Vector2(0, 40)],
	["فرنسا", "France", 1940, Vector2(312, 282), Vector2(70, -26)],
	["لندن", "London", 1940, Vector2(250, 245), Vector2(-60, -24)],
	["موسكو", "Moscow", 1941, Vector2(985, 160), Vector2(0, 40)],
	["العلمين", "El Alamein", 1942, Vector2(848, 698), Vector2(0, -24)],
	["ستالينجراد", "Stalingrad", 1942, Vector2(1112, 298), Vector2(0, 40)],
	["نورماندي", "Normandy", 1944, Vector2(277, 343), Vector2(-70, 48)],
	["الأردين", "Ardennes", 1944, Vector2(378, 305), Vector2(80, 40)],
]
const OPEN_BATTLE := 6

const FIRE_C := Vector2(W - 140.0, H - 150.0)
const FIRE_R := 92.0
const JOY_C := Vector2(165.0, H - 165.0)
const JOY_R := 100.0
const BELT := 60
const PAUSE_BTN := Rect2(W - 86.0, 14.0, 70.0, 56.0)

# ---------------------------------------------------------------- setup
func L(ar: String, en: String) -> String:
	return ar if AR else en

func _ready() -> void:
	randomize()
	AR = OS.get_locale_language() == "ar"
	font = load("res://assets/font/dv.ttf")
	var th := Theme.new()
	th.default_font = font
	th.default_font_size = 28
	theme = th
	for n in ["bg", "boat_closed", "boat_open", "boom", "crate_ammo", "crate_at", "crate_health",
			"mg", "pak", "plane", "sold_fall", "sold_gren", "sold_run", "tank",
			"sold_knee", "dead_back", "dead_front", "reticle", "map"]:
		var ext := ".jpg" if n in ["bg", "map"] else ".png"
		T[n] = load("res://assets/art/" + n + ext)
	for n in ["shot", "mg", "rpg", "boom", "hit", "hurt", "click", "pick"]:
		SND[n] = load("res://assets/snd/%s.wav" % n)
	for i in 10:
		var p := AudioStreamPlayer.new()
		add_child(p)
		players.append(p)
	_load()

	world = Node2D.new()
	add_child(world)
	world.draw.connect(_draw_world)
	fxl = _add_layer(true)
	fxl.draw.connect(_draw_fx)
	gun = Node2D.new()
	add_child(gun)
	gun.draw.connect(_draw_gun)
	gunfx = _add_layer(true)
	gunfx.draw.connect(_draw_gunfx)
	hud = Node2D.new()
	add_child(hud)
	hud.draw.connect(_draw_hud)
	retl = _add_layer(true)
	retl.draw.connect(_draw_reticle)

	flash = ColorRect.new()
	flash.color = Color(0.7, 0, 0, 0)
	flash.size = Vector2(W, H)
	flash.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(flash)

	top_l = _label("", 26, Color(1, 0.93, 0.7), Vector2(W * 0.5 - 300, 14), 600)
	info_l = _label("", 24, Color(1, 0.85, 0.5), Vector2(W * 0.5 - 300, 52), 600)
	banner = _label("", 60, Color(1, 0.9, 0.55), Vector2(0, H * 0.30), W)
	banner.modulate.a = 0.0
	_build_map()
	_build_menu()
	_build_pause()
	_build_end()
	_build_rate()
	_show_map()
	_play_intro()
	if "--autotest" in OS.get_cmdline_user_args():
		_autotest()

# automated play-through used only for local testing (never active in the app)
func _autotest() -> void:
	var t0 := Time.get_ticks_msec()
	var shots := [6.0, 12.0, 18.0, 24.0, 30.0, 36.0, 42.0, 48.0, 54.0, 60.0, 70.0, 80.0]
	await get_tree().create_timer(3.0).timeout
	await _shot("intro")
	_end_intro()
	await get_tree().create_timer(0.5).timeout
	await _shot("map")
	mapc.visible = false
	_start_level(int(OS.get_environment("LVL")) if OS.get_environment("LVL") != "" else 1)
	while true:
		await get_tree().process_frame
		var el := (Time.get_ticks_msec() - t0) / 1000.0
		health = maxf(health, 40.0)
		# aim at nearest live target, prefer crates
		var target := Vector2.ZERO
		var want_cannon := false
		if crates.size() > 0 and _crate_rect(crates[0]).position.y > 40:
			target = _crate_rect(crates[0]).get_center()
		else:
			var bz := 999.0
			for e in ents:
				if e.state in ["fall", "dead", "leave"]:
					continue
				if OS.get_environment("NEAR") != "" and e.z > 2.2:
					continue
				if e.z < bz and e.kind != "boat":
					bz = e.z
					target = _rect(e).get_center()
					want_cannon = e.kind == "tank"
		if OS.get_environment("PASSIVE") != "":
			aim = Vector2(80, 60)
		elif target != Vector2.ZERO:
			aim = aim.lerp(target, 0.25)
			if want_cannon and aim.distance_to(target) < 20.0:
				_cannon()
		if shots.size() > 0 and el > shots[0]:
			shots.pop_front()
			_shot("t%02d_w%d" % [int(el), wave])
		if el > 90.0 or end_p.visible:
			_shot("end")
			print("AUTOTEST level=%d wave=%d health=%d kills=%d ents=%d" % [level, wave, health, wave_kills, ents.size()])
			get_tree().quit()
			return

func _shot(n: String) -> void:
	await RenderingServer.frame_post_draw
	var img := get_viewport().get_texture().get_image()
	img.save_png("/home/claude/normandy/shots12/%s.png" % n)

func _add_layer(additive: bool) -> Node2D:
	var n := Node2D.new()
	if additive:
		var m := CanvasItemMaterial.new()
		m.blend_mode = CanvasItemMaterial.BLEND_MODE_ADD
		n.material = m
	add_child(n)
	return n

func _label(txt: String, size: int, col: Color, pos: Vector2, w: float) -> Label:
	var l := Label.new()
	l.text = txt
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", col)
	l.add_theme_color_override("font_outline_color", Color.BLACK)
	l.add_theme_constant_override("outline_size", 8)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.position = pos
	l.size = Vector2(w, size * 1.6)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(l)
	return l

func _btn(parent: Control, txt: String, pos: Vector2, sz: Vector2, cb: Callable, fs := 32) -> Button:
	var b := Button.new()
	b.text = txt
	b.position = pos
	b.size = sz
	b.add_theme_font_size_override("font_size", fs)
	for st in ["normal", "hover", "pressed", "focus"]:
		var s := StyleBoxFlat.new()
		s.bg_color = Color(0.22, 0.17, 0.1, 0.92) if st != "pressed" else Color(0.4, 0.3, 0.15, 0.95)
		s.border_color = Color(0.85, 0.65, 0.3)
		s.set_border_width_all(3)
		s.set_corner_radius_all(14)
		b.add_theme_stylebox_override(st, s)
	b.add_theme_color_override("font_color", Color(1, 0.92, 0.65))
	b.add_theme_color_override("font_hover_color", Color(1, 0.95, 0.75))
	b.pressed.connect(func(): play("click"); cb.call())
	parent.add_child(b)
	return b

func _panel(alpha := 0.6) -> Control:
	var c := Control.new()
	c.size = Vector2(W, H)
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, alpha)
	dim.size = Vector2(W, H)
	c.add_child(dim)
	add_child(c)
	c.visible = false
	return c

func _plabel(parent: Control, txt: String, size: int, y: float, col := Color(1, 0.9, 0.55)) -> Label:
	var l := Label.new()
	l.text = txt
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", col)
	l.add_theme_color_override("font_outline_color", Color.BLACK)
	l.add_theme_constant_override("outline_size", 10)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.position = Vector2(W * 0.5 - 450, y)
	l.size = Vector2(900, size * 1.5)
	parent.add_child(l)
	return l

func _build_menu() -> void:
	menu = _panel(0.35)
	_plabel(menu, L("الحرب العالمية الثانية", "World War II"), 70, 70)
	_plabel(menu, L("نورماندي 1944", "Normandy 1944"), 44, 165, Color(1, 0.8, 0.45))
	_plabel(menu, L("اصمد في الدُّشمة وصُدّ الإنزال على الشاطئ", "Hold the bunker and stop the beach landing"), 30, 210, Color(1, 0.95, 0.85))
	lvl_l = _plabel(menu, "", 30, 270, Color(1, 0.8, 0.45))
	start_btn = _btn(menu, L("ابدأ المعركة", "Start Battle"), Vector2(W * 0.5 - 170, 360), Vector2(340, 90), _on_start, 38)
	_btn(menu, L("الخريطة", "Map"), Vector2(30, 24), Vector2(190, 64), _show_map, 26)
	_btn(menu, L("من الأول", "Restart"), Vector2(W * 0.5 - 120, 475), Vector2(240, 66), func(): best = 1; _save(); _show_menu(), 26)
	_plabel(menu, L("وجّه النيشان بالأسهم  •  الرشاش بيضرب لوحده\nاضغط «مدفع» للدبابات والمراكب\nاضرب الصندوق اللي محتاجه: صحة أو قذائف أو ذخيرة", "Aim with the arrow pad  •  The machine gun fires when the crosshair is on a target\nTap CANNON for tanks and boats\nShoot the supply crate you need: health, shells or ammo"), 22, 560, Color(0.95, 0.92, 0.85))

func _play_intro() -> void:
	intro = Control.new()
	intro.size = Vector2(W, H)
	add_child(intro)
	var bg := ColorRect.new()
	bg.color = Color.BLACK
	bg.size = Vector2(W, H)
	intro.add_child(bg)
	intro_vp = VideoStreamPlayer.new()
	intro_vp.stream = load("res://assets/intro.ogv")
	intro_vp.expand = true
	intro_vp.size = Vector2(W, H)
	intro.add_child(intro_vp)
	intro_vp.finished.connect(_end_intro)
	var title := _plabel(intro, L("الحرب العالمية الثانية", "World War II"), 72, H * 0.38, Color(0.95, 0.9, 0.8))
	title.modulate.a = 0.0
	var tw := create_tween()
	tw.tween_interval(12.5)
	tw.tween_property(title, "modulate:a", 1.0, 1.0)
	_btn(intro, L("تخطي ◀", "Skip ▶"), Vector2(W - 190, 20), Vector2(170, 60), _end_intro, 26)
	intro_vp.play()

func _end_intro() -> void:
	if intro == null:
		return
	intro_vp.stop()
	intro.queue_free()
	intro = null

func _map_pos(i: int) -> Vector2:
	var tex: Texture2D = T["map"]
	var sc := maxf(W / tex.get_width(), H / tex.get_height())
	var off := (Vector2(W, H) - Vector2(tex.get_width(), tex.get_height()) * sc) * 0.5
	return BATTLES[i][3] * sc + off

func _build_map() -> void:
	mapc = Control.new()
	mapc.size = Vector2(W, H)
	add_child(mapc)
	var tr := TextureRect.new()
	tr.texture = T["map"]
	tr.size = Vector2(W, H)
	tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	tr.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
	mapc.add_child(tr)
	var shade := ColorRect.new()
	shade.color = Color(0, 0, 0, 0.15)
	shade.size = Vector2(W, H)
	mapc.add_child(shade)
	pins = Control.new()
	pins.size = Vector2(W, H)
	pins.mouse_filter = Control.MOUSE_FILTER_IGNORE
	pins.draw.connect(_draw_pins)
	mapc.add_child(pins)
	var t := _plabel(mapc, L("الحرب العالمية الثانية", "World War II"), 46, 8, Color(0.25, 0.15, 0.05))
	t.add_theme_color_override("font_outline_color", Color(0.95, 0.88, 0.7))
	t.add_theme_constant_override("outline_size", 8)
	for i in BATTLES.size():
		var b := Button.new()
		b.flat = true
		b.position = _map_pos(i) - Vector2(45, 45)
		b.size = Vector2(90, 90)
		var idx := i
		b.pressed.connect(func(): _on_battle(idx))
		mapc.add_child(b)
	mapc.visible = false

func _draw_pins() -> void:
	var pulse := 0.5 + 0.5 * sin(Time.get_ticks_msec() / 260.0)
	for i in BATTLES.size():
		var p := _map_pos(i)
		var open := i == OPEN_BATTLE
		var name: String = BATTLES[i][0] if AR else BATTLES[i][1]
		var txt := "%s %d" % [name, BATTLES[i][2]]
		if open:
			pins.draw_circle(p, 22 + pulse * 10, Color(0.85, 0.1, 0.05, 0.25 * (1.0 - pulse) + 0.1))
			pins.draw_circle(p, 15, Color(0.7, 0.05, 0.03))
			pins.draw_arc(p, 15, 0, TAU, 32, Color(1, 0.85, 0.5), 3.0, true)
			pins.draw_circle(p, 5, Color(1, 0.9, 0.6))
		else:
			pins.draw_circle(p, 11, Color(0.25, 0.2, 0.15, 0.85))
			pins.draw_arc(p, 11, 0, TAU, 32, Color(0.85, 0.75, 0.55), 2.0, true)
		var fs := 22 if open else 18
		var tw := font.get_string_size(txt, HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x
		var lo: Vector2 = BATTLES[i][4]
		var lp := p + Vector2(lo.x - tw * 0.5, lo.y)
		var bgc := Color(0.15, 0.08, 0.03, 0.8) if open else Color(0.2, 0.16, 0.1, 0.65)
		pins.draw_rect(Rect2(lp + Vector2(-8, -fs - 2), Vector2(tw + 16, fs + 12)), bgc)
		pins.draw_string(font, lp, txt, HORIZONTAL_ALIGNMENT_LEFT, -1, fs, Color(1, 0.9, 0.6) if open else Color(0.85, 0.8, 0.7))

func _on_battle(i: int) -> void:
	play("click")
	if i == OPEN_BATTLE:
		mapc.visible = false
		_show_menu()
	else:
		_banner(L("المعركة دي جاية قريب", "This battle is coming soon"))

func _show_map() -> void:
	running = false
	menu.visible = false
	pause_p.visible = false
	end_p.visible = false
	rate_p.visible = false
	_clear()
	top_l.text = ""
	info_l.text = ""
	mapc.visible = true

func _build_pause() -> void:
	pause_p = _panel(0.6)
	_plabel(pause_p, L("استراحة", "Paused"), 64, 170)
	_btn(pause_p, L("كمّل", "Continue"), Vector2(W * 0.5 - 150, 300), Vector2(300, 84), func(): pause_p.visible = false; running = true)
	_btn(pause_p, L("القائمة", "Menu"), Vector2(W * 0.5 - 150, 410), Vector2(300, 84), _show_menu)

func _build_end() -> void:
	end_p = _panel(0.62)
	end_title = _plabel(end_p, "", 70, 140)
	end_sub = _plabel(end_p, "", 30, 245, Color(1, 0.95, 0.85))
	end_next = _btn(end_p, L("المستوى التالي", "Next Level"), Vector2(W * 0.5 - 170, 340), Vector2(340, 86), _on_next)
	_btn(end_p, L("إعادة", "Retry"), Vector2(W * 0.5 - 170, 446), Vector2(340, 76), func(): _start_level(level))
	_btn(end_p, L("القائمة", "Menu"), Vector2(W * 0.5 - 170, 542), Vector2(340, 76), _show_menu)

func _build_rate() -> void:
	rate_p = _panel(0.7)
	_plabel(rate_p, L("عجبتك اللعبة؟", "Enjoying the game?"), 60, 150)
	_plabel(rate_p, "★★★★★", 64, 240, Color(1, 0.8, 0.2))
	_plabel(rate_p, L("تقييمك على جوجل بلاي بيساعدنا نكمّل ونضيف معارك جديدة", "Your rating on Google Play helps us add new battles"), 28, 340, Color(1, 0.95, 0.85))
	_btn(rate_p, L("قيّم اللعبة الآن", "Rate Now"), Vector2(W * 0.5 - 190, 430), Vector2(380, 86), _on_rate, 34)
	_btn(rate_p, L("بعدين", "Later"), Vector2(W * 0.5 - 110, 540), Vector2(220, 66), func(): rate_p.visible = false, 26)

# ---------------------------------------------------------------- save
func _load() -> void:
	var c := ConfigFile.new()
	if c.load(SAVE) == OK:
		best = int(c.get_value("g", "best", 1))
		rated = bool(c.get_value("g", "rated", false))

func _save() -> void:
	var c := ConfigFile.new()
	c.set_value("g", "best", best)
	c.set_value("g", "rated", rated)
	c.save(SAVE)

# ---------------------------------------------------------------- flow
func _show_menu() -> void:
	running = false
	pause_p.visible = false
	end_p.visible = false
	rate_p.visible = false
	menu.visible = true
	lvl_l.text = L("المستوى %d", "Level %d") % best
	_clear()
	top_l.text = ""
	info_l.text = ""

func _on_start() -> void:
	_start_level(best)

func _on_next() -> void:
	_start_level(level + 1)

func _on_rate() -> void:
	rated = true
	_save()
	rate_p.visible = false
	if OS.shell_open("market://details?id=" + PKG) != OK:
		OS.shell_open("https://play.google.com/store/apps/details?id=" + PKG)

func _clear() -> void:
	ents.clear(); fx.clear(); smoke.clear(); puffs.clear(); tracers.clear()
	nades.clear(); crates.clear(); pending.clear(); spawn_q.clear(); planes.clear()

func _start_level(l: int) -> void:
	level = l
	menu.visible = false
	end_p.visible = false
	rate_p.visible = false
	pause_p.visible = false
	_clear()
	health = 100.0
	mg_ammo = 900
	belt = BELT
	mg_reload = 0.0
	cannon_view = 0.0
	cannon_shot = -1.0
	joy_idx = -1
	joy = Vector2.ZERO
	at_ammo = 4
	weapon = "mg"
	wave = 0
	aim = Vector2(W * 0.5, H * 0.42)
	firing = false
	fire_idx = -1
	aim_idx = -1
	running = true
	_next_wave()

func _next_wave() -> void:
	wave += 1
	between = -1.0
	wave_t = 0.0
	wave_kills = 0
	dropped = false
	var boats: int = mini(2 + mini(wave, 3) + (level - 1), 8)
	var tanks: int = clampi(int((wave + level - 1) / 2.0) - 1 + (1 if wave == 5 else 0), 0, boats - 1)
	if level == 1 and wave < 3:
		tanks = 0
	var slots: Array = []
	for i in boats:
		slots.append(lerpf(-0.85, 0.85, (i + 0.5) / boats) + randf_range(-0.06, 0.06))
	slots.shuffle()
	wave_units = 0
	var tank_ids: Array = range(boats)
	tank_ids.shuffle()
	tank_ids = tank_ids.slice(0, tanks)
	for i in boats:
		var tk: bool = i in tank_ids
		var cargo := 0 if tk else randi_range(3, 4 + mini(level, 2))
		wave_units += 1 if tk else cargo
		spawn_q.append({"t": i * randf_range(1.6, 2.6), "x": slots[i], "tank": tk, "cargo": cargo})
	_banner(L("المستوى %d  —  الموجة %d من %d", "Level %d  —  Wave %d of %d") % [level, wave, WAVES])

func _banner(txt: String) -> void:
	banner.text = txt
	banner.modulate.a = 1.0
	var tw := create_tween()
	tw.tween_interval(1.6)
	tw.tween_property(banner, "modulate:a", 0.0, 0.6)

func _wave_clear() -> bool:
	if spawn_q.size() > 0:
		return false
	for e in ents:
		if e.kind == "sold" and e.state != "fall":
			return false
		if e.kind == "tank" and e.state != "dead":
			return false
		if e.kind == "boat" and e.state in ["come", "unload"] and (e.cargo > 0 or e.has_tank):
			return false
	return true

func _level_won() -> void:
	running = false
	firing = false
	if level >= best:
		best = level + 1
		_save()
	end_title.text = L("انتصار!", "Victory!")
	end_sub.text = L("صدّيت الإنزال في المستوى %d", "You stopped the landing on level %d") % level
	end_next.visible = true
	end_p.visible = true
	if not rated and not rate_shown:
		rate_shown = true
		rate_p.visible = true
		move_child(rate_p, get_child_count() - 1)

func _game_over() -> void:
	running = false
	firing = false
	end_title.text = L("سقطت الدُّشمة", "The bunker has fallen")
	end_sub.text = L("وصلت للموجة %d في المستوى %d", "You reached wave %d on level %d") % [wave, level]
	end_next.visible = false
	end_p.visible = true

# ---------------------------------------------------------------- projection
func dpx(z: float) -> float:
	return NEAR / z

func sy(z: float) -> float:
	return HOR + dpx(z)

func sx(x: float, z: float) -> float:
	return W * 0.5 + x * (150.0 + dpx(z) * 2.3)

func uh(z: float) -> float:
	return 6.0 + dpx(z) * 0.9

func _rect(e: Ent) -> Rect2:
	var u := uh(e.z)
	var tex: Texture2D = _tex(e)
	var w: float
	var bob := 0.0
	match e.kind:
		"sold":
			var h := u
			w = h * tex.get_width() / tex.get_height()
			if e.state == "run":
				bob = absf(sin(e.ph * 9.0)) * u * 0.06
			if e.state == "fall" and e.t >= 0.45:
				var lw := u * 1.15
				var lh := lw * tex.get_height() / tex.get_width()
				return Rect2(sx(e.x, e.z) - lw * 0.5, sy(e.z) - lh + u * 0.04, lw, lh)
			var r := Rect2(sx(e.x, e.z) - w * 0.5, sy(e.z) - h - bob, w, h)
			if e.state == "fall":
				r.position.y += clampf(e.t / 0.45, 0.0, 1.0) * u * 0.12
			return r
		"boat":
			w = u * 3.3
			bob = sin(e.ph * 2.0) * u * 0.03
			var h2 := w * tex.get_height() / tex.get_width()
			var sink := 0.0
			if e.state == "dead":
				sink = clampf(e.t * 0.35, 0.0, 0.7) * h2
			return Rect2(sx(e.x, e.z) - w * 0.5, sy(e.z) - h2 * 0.92 + bob + sink, w, h2 - sink)
		_:
			w = u * 2.0
			var h3 := w * tex.get_height() / tex.get_width()
			return Rect2(sx(e.x, e.z) - w * 0.5, sy(e.z) - h3, w, h3)

func _tex(e: Ent) -> Texture2D:
	match e.kind:
		"sold":
			if e.state == "fall":
				if e.t >= 0.45:
					return T["dead_back"] if e.cargo == 0 else T["dead_front"]
				return T["sold_fall"] if e.cargo == 0 else T["sold_knee"]
			if e.state == "gren":
				return T["sold_gren"]
			return T["sold_run"]
		"boat":
			return T["boat_open"] if e.state in ["unload", "leave"] else T["boat_closed"]
	return T["tank"]

# ---------------------------------------------------------------- update
func _process(delta: float) -> void:
	var dt := minf(delta, 0.05)
	_update_fx(dt)
	if running:
		_update_game(dt)
	world.position = Vector2(randf_range(-1, 1), randf_range(-1, 1)) * shake * 14.0
	fxl.position = world.position
	gun.position = world.position * 0.6
	gunfx.position = gun.position
	shake = maxf(shake - dt * 2.5, 0.0)
	recoil = maxf(recoil - dt * 10.0, 0.0)
	muzzle = maxf(muzzle - dt, 0.0)
	hurt_a = maxf(hurt_a - dt * 1.6, 0.0)
	flash.color.a = hurt_a * 0.45
	world.queue_redraw()
	fxl.queue_redraw()
	gun.queue_redraw()
	gunfx.queue_redraw()
	hud.queue_redraw()
	retl.queue_redraw()
	if mapc.visible:
		pins.queue_redraw()

func _update_game(dt: float) -> void:
	wave_t += dt
	# spawn boats
	var i := 0
	while i < spawn_q.size():
		var s: Dictionary = spawn_q[i]
		if wave_t >= s["t"]:
			var b := Ent.new()
			b.kind = "boat"
			b.x = s["x"]
			b.z = 46.0
			b.hp = 28.0
			b.state = "come"
			b.cargo = s["cargo"]
			b.has_tank = s["tank"]
			b.spd = randf_range(2.6, 3.2)
			b.ph = randf() * 10.0
			ents.append(b)
			spawn_q.remove_at(i)
		else:
			i += 1
	# weapons
	mg_cd -= dt
	at_reload = maxf(at_reload - dt, 0.0)
	no_ammo_t = maxf(no_ammo_t - dt, 0.0)
	aim += joy * pow(joy.length(), 0.8) * 640.0 * dt
	aim.x = clampf(aim.x, 30.0, W - 30.0)
	aim.y = clampf(aim.y, 40.0, H * 0.76)
	if cannon_view > 0.0:
		cannon_view -= dt
		if cannon_shot >= 0.0:
			cannon_shot -= dt
			if cannon_shot < 0.0:
				_fire_at()
		if cannon_view <= 0.0:
			weapon = "mg"
			recoil = 1.5
	elif mg_reload > 0.0:
		mg_reload -= dt
		if mg_reload <= 0.0:
			belt = mini(BELT, mg_ammo)
			play("click", -4.0)
	elif mg_cd <= 0.0 and _aim_on_target():
		_fire_mg()
	# entities
	for e in ents.duplicate():
		e.ph += dt
		e.t += dt
		match e.kind:
			"boat": _upd_boat(e, dt)
			"sold": _upd_sold(e, dt)
			"tank": _upd_tank(e, dt)
	# grenades
	for n in nades.duplicate():
		n["t"] += dt
		if n["t"] >= n["dur"]:
			nades.erase(n)
			_impact(n["to"], 1.1, 9.0 + level * 0.6)
	for p in pending.duplicate():
		p["t"] -= dt
		if p["t"] <= 0.0:
			pending.erase(p)
			_impact(p["pos"], p["size"], p["dmg"])
	# supply planes
	for pl in planes.duplicate():
		pl["x"] -= 300.0 * dt
		var drops: Array = pl["drops"]
		if drops.size() > 0 and pl["x"] + 60.0 <= drops[0]:
			drops.pop_front()
			var ty: String = pl["types"].pop_front()
			crates.append({"type": ty, "x": pl["x"] + 60.0, "y": pl["y"] + 20.0, "ph": randf() * 5.0})
		if pl["x"] < -500.0:
			planes.erase(pl)
	# crates
	for c in crates.duplicate():
		c["y"] += 55.0 * dt
		c["ph"] += dt
		if c["y"] > H * 0.62:
			crates.erase(c)
	if not dropped and wave_units > 0 and wave_kills * 2 >= wave_units:
		_drop_crates()
	# wave end
	if between < 0.0 and _wave_clear():
		if wave >= WAVES:
			between = 99.0
			get_tree().create_timer(1.5).timeout.connect(_level_won)
		else:
			between = 3.0
			health = minf(health + 10.0, 100.0)
			_banner(L("صدّيت الموجة %d!", "Wave %d repelled!") % wave)
	if between > 0.0 and between < 90.0:
		between -= dt
		if between <= 0.0:
			_next_wave()
	_update_hud_text()

func _upd_boat(e: Ent, dt: float) -> void:
	match e.state:
		"come":
			e.z -= e.spd * dt * clampf(e.z / 20.0, 0.25, 1.0)
			if e.z <= 6.6:
				e.z = 6.6
				e.state = "unload"
				e.t = 0.0
				e.unload_t = 0.3
		"unload":
			e.unload_t -= dt
			if e.unload_t <= 0.0:
				if e.has_tank:
					e.has_tank = false
					var tk := Ent.new()
					tk.kind = "tank"
					tk.x = e.x
					tk.z = e.z - 0.5
					tk.hp = 1.0 + floorf((level - 1) / 2.0)
					tk.state = "move"
					tk.spd = 0.42
					tk.zstop = randf_range(2.2, 2.9)
					tk.cd = randf_range(3.0, 5.0)
					ents.append(tk)
				elif e.cargo > 0:
					e.cargo -= 1
					var s := Ent.new()
					s.kind = "sold"
					s.x = e.x + randf_range(-0.05, 0.05)
					s.z = e.z - 0.35
					s.hp = 2.0
					s.state = "run"
					s.spd = randf_range(0.55, 0.8)
					s.zstop = randf_range(1.05, 1.45)
					s.tx = clampf(e.x + randf_range(-0.45, 0.45), -0.95, 0.95)
					s.flip = randf() < 0.5
					s.ph = randf() * 5.0
					s.cd = randf_range(2.0, 4.0)
					ents.append(s)
				e.unload_t = randf_range(0.35, 0.6)
				if e.cargo <= 0 and not e.has_tank:
					e.state = "leave"
					e.t = 0.0
		"leave":
			if e.t > 2.5:
				e.z += 2.0 * dt
				if e.z > 14.0:
					ents.erase(e)
		"dead":
			_wreck_smoke(e, dt)
			if e.t > 6.0:
				ents.erase(e)

func _upd_sold(e: Ent, dt: float) -> void:
	match e.state:
		"run":
			e.z = maxf(e.z - e.spd * dt, e.zstop)
			e.x = move_toward(e.x, e.tx, dt * 0.08)
			if e.z <= e.zstop:
				e.state = "hold"
			_sold_attack(e, dt)
		"hold":
			_sold_attack(e, dt)
		"gren":
			if e.t >= 0.55 and e.cd < 50.0:
				e.cd = 99.0
				var r := _rect(e)
				var to := Vector2(clampf(r.get_center().x + randf_range(-140, 140), 120, W - 120), H * randf_range(0.80, 0.9))
				nades.append({"t": 0.0, "dur": 1.0, "from": r.position + Vector2(r.size.x * 0.4, 0), "to": to})
			if e.t >= 0.9:
				e.state = "hold"
				e.cd = randf_range(2.5, 4.0)
		"fall":
			if e.t >= 0.45 and e.cd > -5.0:
				e.cd = -7.0
				var rr := _rect(e)
				puffs.append({"p": Vector2(rr.get_center().x, rr.end.y - rr.size.y * 0.3), "s": rr.size.x * 0.7, "t": 0.0, "d": 0.6, "c": Color(0.62, 0.53, 0.42, 0.7)})
			if e.t > 22.0:
				ents.erase(e)

func _sold_attack(e: Ent, dt: float) -> void:
	e.cd -= dt
	if e.z > 4.0 or e.cd > 0.0:
		return
	if e.z < 1.75 and randf() < 0.45:
		e.state = "gren"
		e.t = 0.0
		return
	e.cd = randf_range(1.8, 3.4)
	var r := _rect(e)
	var mp := Vector2(r.get_center().x + (r.size.x * 0.3 if not e.flip else -r.size.x * 0.3), r.position.y + r.size.y * 0.35)
	fx.append({"p": mp, "s": maxf(r.size.y * 0.35, 14.0), "t": 0.0, "d": 0.08, "r": randf() * TAU})
	play("shot", -14.0 + (2.0 - e.z) * 2.0)
	if randf() < 0.35 + level * 0.03:
		_hurt(2.0 + level * 0.4)

func _upd_tank(e: Ent, dt: float) -> void:
	match e.state:
		"move", "hold":
			if e.state == "move":
				e.z = maxf(e.z - e.spd * dt, e.zstop)
				if e.z <= e.zstop:
					e.state = "hold"
			e.cd -= dt
			if e.cd <= 0.0:
				e.cd = randf_range(6.5, 8.5)
				var r := _rect(e)
				var mp := Vector2(r.get_center().x, r.position.y + r.size.y * 0.12)
				fx.append({"p": mp, "s": r.size.x * 0.7, "t": 0.0, "d": 0.18, "r": randf() * TAU})
				play("rpg", -4.0)
				pending.append({"t": 0.45, "pos": Vector2(clampf(mp.x + randf_range(-200, 200), 100, W - 100), H * randf_range(0.78, 0.9)), "size": 1.6, "dmg": 20.0 + level * 2.0})
		"dead":
			_wreck_smoke(e, dt)

func _wreck_smoke(e: Ent, dt: float) -> void:
	e.smoke_t -= dt
	if e.smoke_t <= 0.0:
		e.smoke_t = 0.22
		var r := _rect(e)
		smoke.append({"p": Vector2(r.get_center().x + randf_range(-0.2, 0.2) * r.size.x, r.position.y + r.size.y * 0.3),
			"s": r.size.x * 0.55, "t": 0.0, "d": 3.2, "vy": -26.0 - r.size.x * 0.12, "a": 0.55})

func _update_fx(dt: float) -> void:
	for arr in [fx, smoke, puffs]:
		for f in arr.duplicate():
			f["t"] += dt
			if f["t"] >= f["d"]:
				arr.erase(f)
	for s in smoke:
		s["p"].y += s["vy"] * dt
		s["p"].x += 9.0 * dt
	for tr in tracers.duplicate():
		tr["t"] += dt
		if tr["t"] > 0.07:
			tracers.erase(tr)

# ---------------------------------------------------------------- combat
func _muzzle_pos() -> Vector2:
	var g := _gun_geom()
	var tip: Vector2 = g["tip"]
	return tip + gun.position

func _fire_mg() -> void:
	if mg_ammo <= 0:
		no_ammo_t = 1.0
		return
	if belt <= 0:
		mg_reload = 2.2
		play("click", -2.0)
		return
	mg_cd = 0.085
	mg_ammo -= 1
	belt -= 1
	recoil = 1.0
	muzzle = 0.05
	shake = maxf(shake, 0.12)
	play("mg", -5.0)
	var p := aim + Vector2(randf_range(-3, 3), randf_range(-3, 3))
	tracers.append({"a": _muzzle_pos(), "b": p, "t": 0.0})
	if _hit_crate(p):
		return
	var e := _top_at(p)
	if e == null:
		_puff(p)
		return
	match e.kind:
		"sold":
			_damage(e, 1.0)
		"boat":
			_damage(e, 0.25)
			puffs.append({"p": p, "s": 22.0, "t": 0.0, "d": 0.25, "c": Color(1, 0.8, 0.4, 0.9)})
			if randf() < 0.3:
				play("hit", -12.0)
		"tank":
			puffs.append({"p": p, "s": 26.0, "t": 0.0, "d": 0.2, "c": Color(1, 0.9, 0.5, 1)})
			if randf() < 0.3:
				play("hit", -10.0)

func _aim_on_target() -> bool:
	for c in crates:
		if _crate_rect(c).grow(10).has_point(aim):
			return true
	for o in [Vector2.ZERO, Vector2(12, 0), Vector2(-12, 0), Vector2(0, 12), Vector2(0, -12)]:
		if _top_at(aim + o) != null:
			return true
	return false

func _has_targets() -> bool:
	for e in ents:
		if (e.kind == "sold" and e.state != "fall") or (e.kind == "tank" and e.state != "dead"):
			return true
		if e.kind == "boat" and e.state in ["come", "unload"] and e.z < 30.0:
			return true
	return crates.size() > 0

func _cannon() -> void:
	if cannon_view > 0.0 or at_reload > 0.0:
		return
	if at_ammo <= 0:
		play("click")
		no_ammo_t = 1.2
		return
	weapon = "at"
	cannon_view = 1.3
	cannon_shot = 0.3
	recoil = 1.5
	play("click", -6.0)

func _fire_at() -> void:
	if at_ammo <= 0:
		play("click")
		no_ammo_t = 1.2
		return
	at_ammo -= 1
	at_reload = 2.4
	recoil = 2.2
	muzzle = 0.12
	shake = maxf(shake, 0.55)
	play("rpg", 0.0)
	tracers.append({"a": _muzzle_pos(), "b": aim, "t": 0.0, "w": 6.0})
	var p := aim
	if _hit_crate(p):
		return
	var e := _top_at(p)
	var sz := 0.9
	if e != null:
		match e.kind:
			"tank": _damage(e, 1.0, true); sz = 1.4
			"boat": _damage(e, 99.0, true); sz = 1.3
			_: _damage(e, 9.0, true)
	_explode(p, sz * (0.55 + dpx(_z_at(p)) / NEAR), false)
	# splash damage on soldiers
	for o in ents:
		if o.kind == "sold" and o.state != "fall" and o != e:
			var r := _rect(o)
			if r.get_center().distance_to(p) < 30.0 + r.size.y * 0.6:
				_damage(o, 9.0)

func _z_at(p: Vector2) -> float:
	return NEAR / maxf(p.y - HOR, 6.0)

func _top_at(p: Vector2) -> Ent:
	var best_e: Ent = null
	for e in ents:
		if (e.kind == "sold" and e.state == "fall") or e.state == "dead":
			continue
		if e.kind == "boat" and e.state == "leave":
			continue
		var r := _rect(e)
		if e.kind == "sold":
			r = r.grow_individual(-r.size.x * 0.08, 0, -r.size.x * 0.08, 0).grow(6.0)
		if r.has_point(p) and (best_e == null or e.z < best_e.z):
			best_e = e
	return best_e

func _damage(e: Ent, d: float, heavy := false) -> void:
	e.hp -= d
	if e.hp > 0.0:
		return
	match e.kind:
		"sold":
			e.state = "fall"
			e.t = 0.0
			e.cd = 0.0
			e.cargo = randi() % 2
			wave_kills += 1
			# keep the beach readable: drop the oldest bodies
			var bodies := 0
			for o in ents:
				if o.kind == "sold" and o.state == "fall":
					bodies += 1
			if bodies > 24:
				for o in ents:
					if o.kind == "sold" and o.state == "fall" and o.t > 1.0:
						o.t = maxf(o.t, 20.0)
						break
			play("hit", -6.0)
		"boat":
			e.state = "dead"
			e.t = 0.0
			wave_kills += e.cargo + (1 if e.has_tank else 0)
			e.cargo = 0
			e.has_tank = false
			var r := _rect(e)
			_explode(r.get_center(), r.size.x / 260.0 + 0.4, true)
		"tank":
			e.state = "dead"
			e.t = 0.0
			wave_kills += 1
			var r2 := _rect(e)
			_explode(r2.get_center(), r2.size.x / 220.0 + 0.5, true)

func _hit_crate(p: Vector2) -> bool:
	for c in crates:
		if _crate_rect(c).has_point(p):
			_collect(c)
			return true
	return false

func _collect(c: Dictionary) -> void:
	var txt := ""
	match c["type"]:
		"crate_health":
			health = minf(health + 35.0, 100.0)
			txt = L("صحة +35", "Health +35")
		"crate_at":
			at_ammo += 3
			txt = L("قذائف مدفع +3", "Cannon shells +3")
		"crate_ammo":
			mg_ammo += 400
			txt = L("ذخيرة رشاش +400", "MG ammo +400")
	play("pick")
	_explode(_crate_rect(c).get_center(), 0.35, false)
	crates.clear()
	_banner(txt)

func _drop_crates() -> void:
	dropped = true
	var types := ["crate_health", "crate_at", "crate_ammo"]
	types.shuffle()
	var xs := [W * 0.72 + randf_range(-30, 30), W * 0.42 + randf_range(-30, 30), W * 0.22 + randf_range(-30, 30)]
	planes.append({"x": W + 120.0, "y": 70.0, "drops": [xs[0], xs[2]], "types": [types[0], types[2]]})
	planes.append({"x": W + 520.0, "y": 135.0, "drops": [xs[1]], "types": [types[1]]})
	play("pick", -10.0)
	_banner(L("إمدادات! اضرب الصندوق اللي محتاجه", "Supplies! Shoot the crate you need"))

func _crate_rect(c: Dictionary) -> Rect2:
	var tex: Texture2D = T[c["type"]]
	var h := 190.0
	var w := h * tex.get_width() / tex.get_height()
	return Rect2(c["x"] + sin(c["ph"] * 1.3) * 18.0 - w * 0.5, c["y"], w, h)

func _impact(p: Vector2, size: float, dmg: float) -> void:
	_explode(p, size, false)
	_hurt(dmg)
	shake = maxf(shake, 0.8)

func _hurt(d: float) -> void:
	health -= d
	hurt_a = minf(hurt_a + d / 14.0, 1.0)
	play("hurt", -8.0)
	if health <= 0.0 and running:
		health = 0.0
		_game_over()

func _explode(p: Vector2, size: float, wreck: bool) -> void:
	play("boom", -2.0 if size > 0.8 else -9.0)
	fx.append({"p": p, "s": 260.0 * size, "t": 0.0, "d": 0.7, "r": randf() * TAU})
	smoke.append({"p": p + Vector2(0, -20.0 * size), "s": 280.0 * size, "t": 0.0, "d": 2.4, "vy": -30.0, "a": 0.6})
	if wreck:
		shake = maxf(shake, 0.4)

func _puff(p: Vector2) -> void:
	var water := p.y < sy(6.6) + 4.0
	var c := Color(0.85, 0.9, 1.0, 0.75) if water else Color(0.65, 0.55, 0.42, 0.75)
	var z := _z_at(p)
	puffs.append({"p": p, "s": clampf(dpx(z) * 0.22, 8.0, 46.0), "t": 0.0, "d": 0.35, "c": c})

# ---------------------------------------------------------------- input
func _input(ev: InputEvent) -> void:
	if not running:
		return
	if ev is InputEventScreenTouch:
		_touch(ev.index, ev.position, ev.pressed)
	elif ev is InputEventScreenDrag:
		if ev.index == joy_idx:
			_joy_set(ev.position)
		elif ev.index == aim_idx:
			_move_aim(ev.relative)
	elif not DisplayServer.is_touchscreen_available():
		if ev is InputEventMouseButton and ev.button_index == MOUSE_BUTTON_LEFT:
			_touch(0, ev.position, ev.pressed)
		elif ev is InputEventMouseMotion and joy_idx == 0:
			_joy_set(ev.position)
		elif ev is InputEventMouseMotion and aim_idx == 0:
			_move_aim(ev.relative)

func _touch(idx: int, pos: Vector2, pressed: bool) -> void:
	if pressed:
		if pos.distance_to(FIRE_C) < FIRE_R * 1.15:
			_cannon()
		elif pos.distance_to(JOY_C) < JOY_R * 1.7:
			joy_idx = idx
			_joy_set(pos)
		elif PAUSE_BTN.grow(8).has_point(pos):
			running = false
			firing = false
			pause_p.visible = true
		elif aim_idx == -1:
			aim_idx = idx
	else:
		if idx == joy_idx:
			joy_idx = -1
			joy = Vector2.ZERO
		if idx == aim_idx:
			aim_idx = -1

func _move_aim(rel: Vector2) -> void:
	aim += rel * 1.3
	aim.x = clampf(aim.x, 30.0, W - 30.0)
	aim.y = clampf(aim.y, 40.0, H * 0.76)

func _joy_set(pos: Vector2) -> void:
	var v := (pos - JOY_C) / JOY_R
	if v.length() > 1.0:
		v = v.normalized()
	joy = v if v.length() > 0.12 else Vector2.ZERO

func play(n: String, vol := 0.0) -> void:
	for p in players:
		if not p.playing:
			p.stream = SND[n]
			p.volume_db = vol
			p.play()
			return

# ---------------------------------------------------------------- drawing
func _draw_world() -> void:
	var bg: Texture2D = T["bg"]
	var s := maxf((W + 40) / bg.get_width(), (H + 40) / bg.get_height())
	var bw := bg.get_width() * s
	var bh := bg.get_height() * s
	world.draw_texture_rect(bg, Rect2((W - bw) * 0.5, (H - bh) * 0.5, bw, bh), false)
	var order := ents.duplicate()
	order.sort_custom(func(a, b): return a.z > b.z)
	for e in order:
		var r := _rect(e)
		var col := Color(1, 1, 1, 1)
		if e.state == "dead":
			col = Color(0.28, 0.25, 0.22, 1)
		if e.kind == "boat" and e.state == "leave" and e.z > 8.0:
			col.a = clampf(1.0 - (e.z - 8.0) / 6.0, 0.0, 1.0)
		if e.kind == "sold" and e.state == "fall":
			col = Color(0.88, 0.85, 0.82, clampf((22.0 - e.t) / 2.0, 0.0, 1.0))
		# sun-side tint: far objects get hazy
		var haze := clampf((e.z - 6.0) / 40.0, 0.0, 0.5)
		col = col.lerp(Color(1.0, 0.85, 0.65, col.a), haze)
		var tex := _tex(e)
		if e.kind == "sold" and e.state == "fall" and e.t >= 0.45:
			if e.flip:
				world.draw_texture_rect(tex, Rect2(r.position + Vector2(r.size.x, 0), Vector2(-r.size.x, r.size.y)), false, col)
			else:
				world.draw_texture_rect(tex, r, false, col)
		elif e.kind == "sold" and e.state == "fall":
			var c := r.get_center()
			var ang := clampf(e.t * 1.2, 0.0, 0.5) * (1.0 if e.flip else -1.0) * (1.0 if e.cargo == 0 else 0.3)
			world.draw_set_transform(c, ang, Vector2.ONE)
			world.draw_texture_rect(tex, Rect2(-r.size * 0.5, r.size), false, col)
			world.draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
		elif e.flip and e.kind == "sold":
			world.draw_texture_rect(tex, Rect2(r.position + Vector2(r.size.x, 0), Vector2(-r.size.x, r.size.y)), false, col)
		else:
			world.draw_texture_rect(tex, r, false, col)
		if e.kind == "boat" and e.state == "come":
			# bow wake
			var wy := r.end.y - r.size.y * 0.05
			world.draw_line(Vector2(r.position.x, wy), Vector2(r.end.x, wy), Color(1, 1, 1, 0.35), maxf(r.size.y * 0.05, 1.5))
	# supply planes
	var ptex: Texture2D = T["plane"]
	for pl in planes:
		var pw := 330.0
		var ph2 := pw * ptex.get_height() / ptex.get_width()
		world.draw_texture_rect(ptex, Rect2(pl["x"] - pw * 0.5, pl["y"] - ph2 * 0.5 + sin(pl["x"] * 0.01) * 4.0, pw, ph2), false)
	# crates
	for c in crates:
		world.draw_texture_rect(T[c["type"]], _crate_rect(c), false)
	# grenades in flight
	for n in nades:
		var k: float = n["t"] / n["dur"]
		var a: Vector2 = n["from"]
		var b: Vector2 = n["to"]
		var p := a.lerp(b, k) + Vector2(0, -sin(k * PI) * 160.0)
		var rad := lerpf(3.0, 11.0, k)
		world.draw_circle(p, rad, Color(0.12, 0.13, 0.1))
		world.draw_circle(p + Vector2(-rad * 0.3, -rad * 0.3), rad * 0.35, Color(0.35, 0.36, 0.3))
	# smoke
	var boom: Texture2D = T["boom"]
	for f in smoke:
		var k2: float = f["t"] / f["d"]
		var sz: float = f["s"] * (0.6 + k2 * 0.9)
		var a2: float = f["a"] * (1.0 - k2)
		var hgt := sz * boom.get_height() / boom.get_width()
		world.draw_texture_rect(boom, Rect2(f["p"] - Vector2(sz, hgt) * 0.5, Vector2(sz, hgt)), false, Color(0.09, 0.08, 0.07, a2))
	for pf in puffs:
		var k3: float = pf["t"] / pf["d"]
		var c3: Color = pf["c"]
		c3.a *= 1.0 - k3
		var s3: float = pf["s"] * (0.5 + k3)
		world.draw_texture_rect(boom, Rect2(pf["p"] - Vector2(s3, s3 * 0.7) * 0.5, Vector2(s3, s3 * 0.7)), false, c3)

func _draw_fx() -> void:
	var boom: Texture2D = T["boom"]
	for f in fx:
		var k: float = f["t"] / f["d"]
		var sz: float = f["s"] * (0.45 + k * 0.75)
		var hgt := sz * boom.get_height() / boom.get_width()
		fxl.draw_set_transform(f["p"], f["r"] * 0.15, Vector2.ONE)
		fxl.draw_texture_rect(boom, Rect2(-Vector2(sz, hgt) * 0.5, Vector2(sz, hgt)), false, Color(1, 1, 1, pow(1.0 - k, 1.4)))
	fxl.draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	for tr in tracers:
		var a: Vector2 = tr["a"]
		var b: Vector2 = tr["b"]
		var k2: float = tr["t"] / 0.07
		var p1 := a.lerp(b, clampf(k2 * 1.4 - 0.35, 0.0, 1.0))
		var p2 := a.lerp(b, clampf(k2 * 1.4 + 0.15, 0.0, 1.0))
		fxl.draw_line(p1 - fxl.position, p2 - fxl.position, Color(1, 0.75, 0.35, 0.9), tr.get("w", 2.5))

func _gun_geom() -> Dictionary:
	var tex: Texture2D = T["mg"] if weapon == "mg" else T["pak"]
	var w: float
	var h: float
	if weapon == "mg":
		h = H * 0.6
		w = h * tex.get_width() / tex.get_height()
	else:
		w = W * 0.62
		h = w * tex.get_height() / tex.get_width()
	var off := (aim.x - W * 0.5) * 0.55
	var ang := (aim.x - W * 0.5) / W * 0.3
	var tip_y := clampf(aim.y + 75.0, H * 0.44, H - 150.0)
	var base := Vector2(W * 0.5 + off, tip_y + h * 0.98 + recoil * 10.0)
	var tipl := Vector2(w * (-0.025 if weapon == "mg" else 0.0), -h * 0.98)
	var tip := base + tipl.rotated(ang)
	return {"tex": tex, "w": w, "h": h, "base": base, "ang": ang, "tip": tip}

func _draw_gun() -> void:
	var g := _gun_geom()
	gun.draw_set_transform(g["base"], g["ang"], Vector2.ONE)
	gun.draw_texture_rect(g["tex"], Rect2(-g["w"] * 0.5, -g["h"], g["w"], g["h"]), false)
	gun.draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)

func _draw_gunfx() -> void:
	if muzzle <= 0.0:
		return
	var g := _gun_geom()
	var boom: Texture2D = T["boom"]
	var sz := 150.0 if weapon == "mg" else 300.0
	gunfx.draw_set_transform(g["tip"], randf() * TAU, Vector2.ONE)
	gunfx.draw_texture_rect(boom, Rect2(-sz * 0.5, -sz * 0.35, sz, sz * 0.7), false, Color(1, 1, 1, 1))
	gunfx.draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)

func _draw_hud() -> void:
	if menu.visible or mapc.visible:
		return
	# crosshair
	if weapon == "at" and at_reload > 0.0:
		hud.draw_arc(aim, 92, -PI / 2, -PI / 2 + TAU * (1.0 - at_reload / 2.4), 64, Color(1, 0.8, 0.2, 0.95), 5.0, true)
	# health
	var hb := Rect2(24, 22, 300, 26)
	hud.draw_rect(hb.grow(3), Color(0, 0, 0, 0.6))
	var hc := Color(0.25, 0.8, 0.3) if health > 50 else (Color(0.95, 0.75, 0.15) if health > 25 else Color(0.95, 0.15, 0.1))
	hud.draw_rect(Rect2(hb.position, Vector2(hb.size.x * health / 100.0, hb.size.y)), hc)
	hud.draw_string(font, Vector2(30, 76), L("الصحة %d", "Health %d") % int(health), HORIZONTAL_ALIGNMENT_LEFT, -1, 22, Color(1, 1, 1))
	# cannon button
	var ready := at_reload <= 0.0 and cannon_view <= 0.0 and at_ammo > 0
	hud.draw_circle(FIRE_C, FIRE_R, Color(0.75, 0.1, 0.08, 0.7 if ready else 0.35))
	hud.draw_arc(FIRE_C, FIRE_R, 0, TAU, 64, Color(1, 0.85, 0.6, 0.9), 4.0, true)
	if at_reload > 0.0:
		hud.draw_arc(FIRE_C, FIRE_R - 8, -PI / 2, -PI / 2 + TAU * (1.0 - at_reload / 2.4), 48, Color(1, 0.8, 0.2, 0.95), 8.0, true)
	hud.draw_string(font, FIRE_C + Vector2(-FIRE_R, -4), L("مدفع", "CANNON"), HORIZONTAL_ALIGNMENT_CENTER, FIRE_R * 2, 36, Color(1, 0.95, 0.85))
	hud.draw_string(font, FIRE_C + Vector2(-FIRE_R, 38), "× %d" % at_ammo, HORIZONTAL_ALIGNMENT_CENTER, FIRE_R * 2, 30, Color(1, 0.85, 0.5))
	# arrow pad (joystick)
	hud.draw_circle(JOY_C, JOY_R, Color(0, 0, 0, 0.35))
	hud.draw_arc(JOY_C, JOY_R, 0, TAU, 64, Color(1, 0.9, 0.7, 0.7), 3.0, true)
	for d in [Vector2(1, 0), Vector2(-1, 0), Vector2(0, 1), Vector2(0, -1)]:
		var tip: Vector2 = JOY_C + d * (JOY_R - 12)
		var side: Vector2 = Vector2(-d.y, d.x) * 16
		var lit := joy.dot(d) > 0.4
		hud.draw_colored_polygon(PackedVector2Array([tip, tip - d * 26 + side, tip - d * 26 - side]), Color(1, 0.85, 0.4, 0.95) if lit else Color(1, 0.95, 0.85, 0.7))
	hud.draw_circle(JOY_C + joy * JOY_R * 0.55, 30, Color(1, 0.95, 0.85, 0.35))
	# machine-gun belt
	var bx := Vector2(24, 118)
	hud.draw_rect(Rect2(bx, Vector2(300, 16)).grow(3), Color(0, 0, 0, 0.6))
	if mg_reload > 0.0:
		hud.draw_rect(Rect2(bx, Vector2(300 * (1.0 - mg_reload / 2.2), 16)), Color(0.9, 0.6, 0.15))
		hud.draw_string(font, bx + Vector2(6, 44), L("بيعبّي الشريط...", "Reloading belt..."), HORIZONTAL_ALIGNMENT_LEFT, -1, 22, Color(1, 0.8, 0.4))
	else:
		hud.draw_rect(Rect2(bx, Vector2(300.0 * belt / BELT, 16)), Color(0.95, 0.8, 0.35))
		hud.draw_string(font, bx + Vector2(6, 44), L("رشاش %d    احتياطي %d", "MG %d    Reserve %d") % [belt, maxi(mg_ammo - belt, 0)], HORIZONTAL_ALIGNMENT_LEFT, -1, 22, Color(1, 0.95, 0.85))
	# pause
	hud.draw_rect(PAUSE_BTN, Color(0, 0, 0, 0.45))
	hud.draw_rect(Rect2(PAUSE_BTN.position + Vector2(24, 14), Vector2(8, 28)), Color(1, 0.92, 0.7))
	hud.draw_rect(Rect2(PAUSE_BTN.position + Vector2(40, 14), Vector2(8, 28)), Color(1, 0.92, 0.7))
	if no_ammo_t > 0.0:
		hud.draw_string(font, Vector2(0, aim.y + 100), L("الذخيرة خلصت! اضرب صندوق الإمدادات", "Out of ammo! Shoot a supply crate"), HORIZONTAL_ALIGNMENT_CENTER, W, 28, Color(1, 0.4, 0.3))

func _draw_reticle() -> void:
	if menu.visible or mapc.visible:
		return
	var tex: Texture2D = T["reticle"]
	var sz := 170.0
	var on := _aim_on_target()
	var c := Color(1, 0.55, 0.45, 1) if on else Color(1, 1, 1, 0.95)
	retl.draw_texture_rect(tex, Rect2(aim - Vector2(sz, sz) * 0.5, Vector2(sz, sz)), false, c)

func _update_hud_text() -> void:
	top_l.text = L("المستوى %d   •   الموجة %d من %d", "Level %d   •   Wave %d of %d") % [level, wave, WAVES]
	var left := 0
	for e in ents:
		if (e.kind == "sold" and e.state != "fall") or (e.kind == "tank" and e.state != "dead"):
			left += 1
		elif e.kind == "boat" and e.state in ["come", "unload"]:
			left += e.cargo + (1 if e.has_tank else 0)
	for s in spawn_q:
		left += 1 if s["tank"] else int(s["cargo"])
	info_l.text = L("العدو المتبقي: %d", "Enemies left: %d") % left
