extends Control
# London 1940 — free-turning chase-camera bombing mission
# World: x = east, z = north, y = altitude. England (land) starts at COAST_Z, London at CITY_Z.

const H := 720.0
const F := 640.0            # focal length in pixels
const PAD := 300.0          # extra border so the view can roll without showing edges
const HORV := 290.0 + PAD   # horizon line in view coordinates
const SPEED := 120.0        # forward speed m/s
const GRAV := 12.0          # bomb gravity (arcade, slow fall so the target stays in view)
const AHEAD := 16.0         # player plane distance in front of the camera
const AIM := 170.0          # gun convergence distance in front of the plane
const ES := 1.8             # aircraft display scale (arcade readability)
const TURN := 0.75          # max turn rate rad/s
const COAST_Z := 2600.0
const CITY_Z := 4300.0
const RADAR_RANGE := 1600.0
const JOY_R := 100.0
const BOMB_R := 92.0
const RADAR_R := 92.0

var W := 1280.0
var CXV := 640.0 + PAD
var JOY_C := Vector2(165.0, H - 165.0)
var BOMB_C := Vector2(1140.0, H - 150.0)
var PAUSE_BTN := Rect2(1194.0, 14.0, 70.0, 56.0)
var RADAR_C := Vector2(1160.0, 190.0)

var m          # main.gd node (font, sounds, texts, save)
var level := 1
var T := {}

var view: Control
var gmat: ShaderMaterial
var air: Node2D
var fxl: Node2D
var plane_l: Node2D
var plane_fx: Node2D
var ret_l: Node2D
var hud: Node2D
var shade: ColorRect
var hurt: ColorRect
var top_l: Label
var info_l: Label
var banner: Label
var brief: Control
var brief_draw: Control
var pause_p: Control
var end_p: Control
var end_title: Label
var end_sub: Label
var end_next: Button

var running := false
var t_all := 0.0
var wx := 0.0
var wz := 0.0
var py := 95.0
var hd := 0.0               # heading (0 = north)
var turn := 0.0
var chd := 0.0              # camera heading (lags a little)
var camx := 0.0
var camz := 0.0
var camy := 101.0
var fwd := Vector2(0, 1)
var rgt := Vector2(1, 0)

var health := 100.0
var bombs := 3
var mg_cd := 0.0
var firing := false
var muzzle := 0.0
var shake := 0.0
var hurt_a := 0.0
var fade_a := 0.0
var joy := Vector2.ZERO
var joy_idx := -1

var enemies: Array = []
var smoke: Array = []
var fx: Array = []
var tracers: Array = []
var etracers: Array = []
var bombs_air: Array = []
var ground_fx: Array = []
var flak: Array = []
var clouds: Array = []
var cloud_t := 0.0
var flak_t := 0.0
var spawn_left := 0
var spawn_t := 0.0
var head_t := 9.0
var kills := 0

var tx := 0.0
var tz := 0.0
var target_alive := true
var objective := "fight"    # fight -> target -> home -> done
var passed_warn := false

# ---------------------------------------------------------------- setup
func setup(main_node, lvl: int) -> void:
	m = main_node
	level = lvl
	W = m.W
	CXV = W * 0.5 + PAD
	BOMB_C = Vector2(W - 140.0, H - 150.0)
	PAUSE_BTN = Rect2(W - 86.0, 14.0, 70.0, 56.0)
	RADAR_C = Vector2(W - 130.0, 185.0)
	size = Vector2(W, H)
	for n in ["cloud0", "cloud1", "cloud2", "stuka", "spit_rear", "spit_front", "bomb", "boom", "reticle", "btn_dpad", "btn_cannon", "map"]:
		T[n] = m.T[n] if m.T.has(n) else load("res://assets/art/" + n + ".png")
	for n in ["city", "sea", "fields", "sky"]:
		T[n] = load("res://assets/art/" + n + ".jpg")

	var bg := ColorRect.new()
	bg.color = Color(0.1, 0.08, 0.06)
	bg.size = Vector2(W, H)
	add_child(bg)
	view = Control.new()
	view.position = Vector2(-PAD, -PAD)
	view.size = Vector2(W + PAD * 2, H + PAD * 2)
	view.pivot_offset = view.size * 0.5
	add_child(view)
	var sky := Node2D.new()
	sky.name = "sky"
	sky.draw.connect(_draw_sky.bind(sky))
	view.add_child(sky)
	var ground := ColorRect.new()
	ground.size = view.size
	gmat = ShaderMaterial.new()
	gmat.shader = load("res://ground.gdshader")
	gmat.set_shader_parameter("sea_tex", T["sea"])
	gmat.set_shader_parameter("land_tex", T["fields"])
	gmat.set_shader_parameter("city_tex", T["city"])
	gmat.set_shader_parameter("rect_size", view.size)
	gmat.set_shader_parameter("hor", HORV)
	gmat.set_shader_parameter("cx", CXV)
	gmat.set_shader_parameter("focal", F)
	gmat.set_shader_parameter("land_start", COAST_Z)
	gmat.set_shader_parameter("land_end", 1e9)
	gmat.set_shader_parameter("city_start", CITY_Z)
	gmat.set_shader_parameter("city_end", 1e9)
	ground.material = gmat
	view.add_child(ground)
	air = Node2D.new()
	view.add_child(air)
	air.draw.connect(_draw_air)
	fxl = _layer(view, true)
	fxl.draw.connect(_draw_fx)

	plane_l = Node2D.new()
	add_child(plane_l)
	plane_l.draw.connect(_draw_plane)
	plane_fx = _layer(self, true)
	plane_fx.draw.connect(_draw_plane_fx)
	ret_l = _layer(self, true)
	ret_l.draw.connect(_draw_reticle)
	hud = Node2D.new()
	add_child(hud)
	hud.draw.connect(_draw_hud)
	hurt = ColorRect.new()
	hurt.color = Color(0.7, 0, 0, 0)
	hurt.size = Vector2(W, H)
	hurt.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(hurt)
	top_l = _label("", 26, Color(1, 0.93, 0.7), Vector2(W * 0.5 - 330, 14), 660)
	info_l = _label("", 22, Color(1, 0.85, 0.5), Vector2(W * 0.5 - 330, 52), 660)
	banner = _label("", 46, Color(1, 0.9, 0.55), Vector2(0, H * 0.2), W)
	banner.modulate.a = 0.0
	_build_brief()
	_build_pause()
	_build_end()
	shade = ColorRect.new()
	shade.color = Color(0, 0, 0, 0)
	shade.size = Vector2(W, H)
	shade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(shade)
	_reset()
	brief.visible = true

func _layer(parent: Node, additive: bool) -> Node2D:
	var n := Node2D.new()
	if additive:
		var mt := CanvasItemMaterial.new()
		mt.blend_mode = CanvasItemMaterial.BLEND_MODE_ADD
		n.material = mt
	parent.add_child(n)
	return n

func _label(txt: String, sz: int, col: Color, pos: Vector2, w: float) -> Label:
	var l := Label.new()
	l.text = txt
	l.add_theme_font_size_override("font_size", sz)
	l.add_theme_color_override("font_color", col)
	l.add_theme_color_override("font_outline_color", Color.BLACK)
	l.add_theme_constant_override("outline_size", 8)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.position = pos
	l.size = Vector2(w, sz * 1.6)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(l)
	return l

func L(a: String, e: String) -> String:
	return m.L(a, e)

func _panel() -> Control:
	var c := Control.new()
	c.size = Vector2(W, H)
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.62)
	dim.size = Vector2(W, H)
	c.add_child(dim)
	add_child(c)
	c.visible = false
	return c

# ---------------------------------------------------------------- briefing
var map_reg := Rect2(90, 85, 560, 315)

func _map_pt(p: Vector2) -> Vector2:
	return (p - map_reg.position) / map_reg.size * Vector2(W, H)

func _build_brief() -> void:
	brief = Control.new()
	brief.size = Vector2(W, H)
	add_child(brief)
	var rw := 315.0 * W / H
	map_reg = Rect2(clampf(370.0 - rw * 0.5, 0.0, 1376.0 - rw), 85, rw, 315)
	var at := AtlasTexture.new()
	at.atlas = T["map"]
	at.region = map_reg
	var tr := TextureRect.new()
	tr.texture = at
	tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	tr.size = Vector2(W, H)
	brief.add_child(tr)
	brief_draw = Control.new()
	brief_draw.size = Vector2(W, H)
	brief_draw.mouse_filter = Control.MOUSE_FILTER_IGNORE
	brief_draw.draw.connect(_draw_brief)
	brief.add_child(brief_draw)
	var px0 := W - 640.0
	var head: Label = m._plabel(brief, L("المهمة: الهجوم على لندن 1940", "Mission: The Attack on London 1940"), 34, 128, Color(1, 0.86, 0.5))
	head.position = Vector2(px0, 128)
	head.size = Vector2(580, 60)
	var n := level
	var lines := [
		L("• اعبر القنال وأسقط طيارة إنجليزية واحدة بالرشاش" if n == 1 else "• اعبر القنال وأسقط %d طيارات إنجليزية بالرشاش" % n, "• Cross the Channel and shoot down %d British fighter%s" % [n, "" if n == 1 else "s"]),
		L("• اتبع الرادار للمبنى المعلّم بالأحمر في لندن", "• Follow the radar to the building marked in red in London"),
		L("• ارمي القنبلة قبل ما توصل فوق الهدف بشوية", "• Release the bomb a little before you reach the target"),
		L("• تفادى نيران المدافع الأرضية", "• Dodge the anti-aircraft fire"),
		L("• لف وارجع جنوب للقاعدة بسلام", "• Turn back south and return to base"),
	]
	var y := 200.0
	var d := 0.4
	for s in lines:
		var l: Label = m._plabel(brief, s, 22, y, Color(0.98, 0.93, 0.82))
		l.position = Vector2(px0, y)
		l.size = Vector2(580, 60)
		l.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT if m.AR else HORIZONTAL_ALIGNMENT_LEFT
		l.visible_ratio = 0.0
		var tw := create_tween()
		tw.tween_interval(d)
		tw.tween_property(l, "visible_ratio", 1.0, 0.7)
		d += 0.65
		y += 68.0
	var b: Button = m._btn(brief, L("انطلق", "Take Off"), Vector2(px0 + 150, 550), Vector2(280, 84), _go, 36)
	m._btn(brief, L("الخريطة", "Map"), Vector2(30, 24), Vector2(190, 64), _exit, 26)
	b.modulate.a = 0.0
	var tw2 := create_tween()
	tw2.tween_interval(d)
	tw2.tween_property(b, "modulate:a", 1.0, 0.5)

func _draw_brief() -> void:
	var lon := _map_pt(Vector2(250, 245))
	var start := _map_pt(Vector2(330, 312))
	var pulse := 0.5 + 0.5 * sin(Time.get_ticks_msec() / 250.0)
	var pr := Rect2(W - 664.0, 112, 620, 540)
	brief_draw.draw_rect(pr, Color(0.08, 0.06, 0.04, 0.84))
	brief_draw.draw_rect(pr, Color(0.85, 0.65, 0.3), false, 3.0)
	brief_draw.draw_rect(pr.grow(-8), Color(0.85, 0.65, 0.3, 0.4), false, 1.0)
	var segs := 14
	for i in segs:
		if i % 2 == 0:
			brief_draw.draw_line(start.lerp(lon, float(i) / segs), start.lerp(lon, float(i + 1) / segs), Color(0.75, 0.1, 0.05, 0.9), 4.0, true)
	brief_draw.draw_circle(start, 8, Color(0.2, 0.2, 0.2))
	brief_draw.draw_circle(lon, 26 + pulse * 14, Color(0.85, 0.08, 0.03, 0.25 * (1.0 - pulse) + 0.1))
	brief_draw.draw_arc(lon, 22, 0, TAU, 40, Color(0.85, 0.08, 0.03), 4.0, true)
	brief_draw.draw_line(lon + Vector2(-30, 0), lon + Vector2(30, 0), Color(0.85, 0.08, 0.03), 3.0)
	brief_draw.draw_line(lon + Vector2(0, -30), lon + Vector2(0, 30), Color(0.85, 0.08, 0.03), 3.0)
	brief_draw.draw_string(m.font, lon + Vector2(-60, -40), L("الهدف", "TARGET"), HORIZONTAL_ALIGNMENT_CENTER, 120, 24, Color(0.75, 0.05, 0.02))

func _go() -> void:
	brief.visible = false
	running = true
	spawn_left = level
	spawn_t = 2.5
	_banner(L("عبور القنال", "Crossing the Channel"))

func _build_pause() -> void:
	pause_p = _panel()
	m._plabel(pause_p, L("استراحة", "Paused"), 64, 170)
	m._btn(pause_p, L("كمّل", "Continue"), Vector2(W * 0.5 - 150, 300), Vector2(300, 84), func(): pause_p.visible = false; running = true)
	m._btn(pause_p, L("الخريطة", "Map"), Vector2(W * 0.5 - 150, 410), Vector2(300, 84), _exit)

func _build_end() -> void:
	end_p = _panel()
	end_title = m._plabel(end_p, "", 66, 140)
	end_sub = m._plabel(end_p, "", 28, 240, Color(1, 0.95, 0.85))
	end_next = m._btn(end_p, L("المستوى التالي", "Next Level"), Vector2(W * 0.5 - 170, 330), Vector2(340, 84), func(): _restart(level + 1))
	m._btn(end_p, L("إعادة", "Retry"), Vector2(W * 0.5 - 170, 432), Vector2(340, 76), func(): _restart(level))
	m._btn(end_p, L("الخريطة", "Map"), Vector2(W * 0.5 - 170, 526), Vector2(340, 76), _exit)

func _restart(l: int) -> void:
	var nl = load("res://london.gd").new()
	m.add_child(nl)
	nl.setup(m, l)
	queue_free()

func _exit() -> void:
	m._show_map()
	queue_free()

# ---------------------------------------------------------------- state
func _reset() -> void:
	wx = 0.0
	wz = 0.0
	py = 95.0
	hd = 0.0
	chd = 0.0
	_update_camera(1.0)
	health = 100.0
	bombs = 3
	tx = randf_range(-120.0, 120.0)
	tz = CITY_Z + 1100.0
	target_alive = true
	objective = "fight"
	clouds.clear()
	for i in 10:
		_spawn_cloud(randf_range(150.0, 1100.0), randf_range(-0.6, 0.6))

func _fwd() -> Vector2:
	return Vector2(sin(hd), cos(hd))

func _rgt() -> Vector2:
	return Vector2(cos(hd), -sin(hd))

func _spawn_cloud(dist: float, side: float) -> void:
	var near := randf() < 0.35
	var lat := randf_range(-60.0, 60.0) if near else side * 700.0 + randf_range(-200.0, 200.0)
	var p := Vector2(wx, wz) + _fwd() * dist + _rgt() * lat
	clouds.append({"x": p.x, "y": py + randf_range(-25.0, 90.0), "z": p.y, "i": randi() % 3, "s": randf_range(70.0, 150.0)})

func _banner(txt: String) -> void:
	banner.text = txt
	banner.modulate.a = 1.0
	var tw := create_tween()
	tw.tween_interval(1.8)
	tw.tween_property(banner, "modulate:a", 0.0, 0.6)

func _update_camera(k: float) -> void:
	chd = lerp_angle(chd, hd, k)
	fwd = Vector2(sin(chd), cos(chd))
	rgt = Vector2(cos(chd), -sin(chd))
	var c := Vector2(wx, wz) - fwd * AHEAD
	camx = c.x
	camz = c.y
	camy = clampf(lerpf(camy, py + 6.0, k), py + 3.0, py + 9.0)

# world (x, y, z) -> view (sx, sy, scale). scale <= 0 means behind the camera
func proj(x: float, y: float, z: float) -> Vector3:
	var d := Vector2(x - camx, z - camz)
	var dz := d.dot(fwd)
	if dz < 2.0:
		return Vector3(-99999, -99999, 0)
	var k := F / dz
	return Vector3(CXV + d.dot(rgt) * k, HORV + (camy - y) * k, k)

func _rel(x: float, z: float) -> Vector2:   # (right, forward) relative to the player
	var d := Vector2(x - wx, z - wz)
	return Vector2(d.dot(_rgt()), d.dot(_fwd()))

func _depth(x: float, z: float) -> float:
	return Vector2(x - camx, z - camz).dot(fwd)

# ---------------------------------------------------------------- update
func _process(delta: float) -> void:
	var dt := minf(delta, 0.05)
	if brief.visible:
		brief_draw.queue_redraw()
	if running:
		_update(dt)
	_update_fx(dt)
	view.rotation = -turn * 0.2
	view.position = Vector2(-PAD, -PAD) + Vector2(randf_range(-1, 1), randf_range(-1, 1)) * shake * 12.0
	shake = maxf(shake - dt * 2.5, 0.0)
	muzzle = maxf(muzzle - dt, 0.0)
	hurt_a = maxf(hurt_a - dt * 1.5, 0.0)
	hurt.color.a = hurt_a * 0.45
	# sky slides sideways with the heading so turning feels real
	view.get_node("sky").queue_redraw()
	gmat.set_shader_parameter("cam", Vector2(camx, camz))
	gmat.set_shader_parameter("dir", fwd)
	gmat.set_shader_parameter("cam_h", camy)
	var mist := 0.0
	for c in clouds:
		var rp := _rel(c["x"], c["z"])
		if rp.y > -10.0 and rp.y < 60.0 and absf(rp.x) < c["s"] * 0.35 and absf(c["y"] - py) < c["s"] * 0.2:
			mist = maxf(mist, 1.0 - absf(rp.y) / 60.0)
	shade.color = Color(0.95, 0.9, 0.82, mist * 0.55) if mist * 0.55 > fade_a else Color(0, 0, 0, fade_a)
	for n in [air, fxl, plane_l, plane_fx, ret_l, hud]:
		n.queue_redraw()

func _update(dt: float) -> void:
	t_all += dt
	# left/right turns the plane, up/down changes altitude
	turn = lerpf(turn, joy.x, minf(dt * 3.5, 1.0))
	hd += turn * TURN * dt
	py = clampf(py - joy.y * 30.0 * dt, 65.0, 150.0)
	var f := _fwd()
	wx += f.x * SPEED * dt
	wz += f.y * SPEED * dt
	_update_camera(minf(dt * 3.0, 1.0))
	if spawn_left > 0:
		spawn_t -= dt
		if spawn_t <= 0.0:
			_spawn_enemy()
			spawn_left -= 1
			spawn_t = 1.6
			if spawn_left == level - 1:
				_banner(L("طيارات العدو! أسقطهم", "Enemy fighters! Shoot them down"))
	match objective:
		"fight":
			if spawn_left == 0 and enemies.is_empty():
				objective = "target"
				_banner(L("اتبع الرادار للهدف في لندن", "Follow the radar to the target in London"))
		"target":
			if not target_alive:
				objective = "home"
				_banner(L("تم تدمير الهدف! لف وارجع جنوب للقاعدة", "Target destroyed! Turn back south to base"))
			else:
				var rp := _rel(tx, tz)
				if rp.y < -150.0 and absf(rp.x) < 400.0 and not passed_warn and bombs_air.is_empty():
					passed_warn = true
					_banner(L("فاتك الهدف! لف وارجعله", "Missed it! Turn around and come back"))
				if rp.y > 300.0:
					passed_warn = false
				if bombs <= 0 and bombs_air.is_empty():
					_fail(L("القنابل خلصت والهدف لسه سليم", "Out of bombs — the target survived"))
		"home":
			if wz < COAST_Z - 500.0:
				_win()
	if wz > COAST_Z - 100.0:
		var iv := (0.75 - level * 0.12) if wz > CITY_Z - 200.0 else (1.25 - level * 0.2)
		_flak(dt, iv)
	cloud_t -= dt
	if cloud_t <= 0.0:
		cloud_t = randf_range(1.0, 2.2)
		_spawn_cloud(randf_range(800.0, 1100.0), randf_range(-1.0, 1.0))
	for c in clouds.duplicate():
		var rp2 := _rel(c["x"], c["z"])
		if rp2.y < -40.0 or rp2.length() > 1600.0:
			clouds.erase(c)
	mg_cd -= dt
	firing = false
	var on = _enemy_on_reticle()
	if on != null:
		firing = true
		if mg_cd <= 0.0:
			mg_cd = 0.08
			_fire(on)
	_update_enemies(dt)
	_update_bombs(dt)
	for fl in flak.duplicate():
		fl["t"] += dt
		var d3 := Vector3(fl["x"] - wx, fl["y"] - py, fl["z"] - wz).length()
		if not fl["hit"] and d3 < 22.0:
			fl["hit"] = true
			_hurt(9.0 + level)
			shake = maxf(shake, 0.9)
		if fl["t"] > 5.0:
			flak.erase(fl)
	_status()

func _status() -> void:
	top_l.text = L("لندن 1940 — المستوى %d", "London 1940 — Level %d") % level
	match objective:
		"fight":
			info_l.text = L("طيارات العدو: %d", "Enemy fighters: %d") % (enemies.size() + spawn_left)
		"target":
			info_l.text = L("المسافة للهدف: %d م", "Distance to target: %d m") % int(Vector2(tx - wx, tz - wz).length())
		"home":
			info_l.text = L("القاعدة جنوب — المسافة للبحر: %d م", "Base is south — distance to the sea: %d m") % int(maxf(wz - (COAST_Z - 500.0), 0.0))
		_:
			info_l.text = ""

func _spawn_enemy() -> void:
	var p := Vector2(wx, wz) + _fwd() * 600.0 + _rgt() * randf_range(-200.0, 200.0)
	enemies.append({
		"x": p.x, "y": py + randf_range(-15.0, 25.0), "z": p.y,
		"ph": randf() * TAU, "hp": 12.0 + level * 3.0, "max": 12.0 + level * 3.0,
		"mode": "chase", "t": 0.0, "rot": 0.0, "smoke_t": 0.0, "fire_t": 0.0,
		"d": randf_range(120.0, 170.0), "vx": 0.0, "hd": hd, "t2": 0.0,
	})

# enemies keep station ahead of the player but catch up slowly, so hard turns throw them off
func _update_enemies(dt: float) -> void:
	head_t -= dt
	var f := _fwd()
	var r := _rgt()
	for e in enemies.duplicate():
		e["t"] += dt
		var old_rel := _rel(e["x"], e["z"])
		match e["mode"]:
			"chase":
				var agg := 0.4 + level * 0.12
				var lat: float = 60.0 * sin(e["t"] * agg + e["ph"]) + 20.0 * sin(e["t"] * agg * 2.3)
				var dd: float = e["d"] + 45.0 * sin(e["t"] * 0.25 + e["ph"])
				var want := Vector2(wx, wz) + f * dd + r * lat
				var cur := Vector2(e["x"], e["z"])
				var ef := Vector2(sin(e["hd"]), cos(e["hd"]))
				cur += ef * SPEED * dt
				var corr := want - cur
				var cap := (55.0 + level * 10.0) * dt
				if corr.length() > cap:
					corr = corr.normalized() * cap
				cur += corr
				e["x"] = cur.x
				e["z"] = cur.y
				e["y"] = lerpf(e["y"], py + 22.0 * sin(e["t"] * 0.55 + e["ph"] * 1.7), minf(dt * 0.8, 1.0))
				e["hd"] = lerp_angle(e["hd"], hd, minf(dt * (0.9 + level * 0.25), 1.0))
				if head_t <= 0.0 and e["t"] > 6.0:
					head_t = randf_range(13.0, 17.0) - level * 2.0
					e["mode"] = "away"
			"away":
				var cur2 := Vector2(e["x"], e["z"]) + f * (SPEED + 170.0) * dt
				e["x"] = cur2.x
				e["z"] = cur2.y
				if _rel(e["x"], e["z"]).y > 520.0:
					e["mode"] = "head"
					var p := Vector2(wx, wz) + f * 520.0 + r * randf_range(-20.0, 20.0)
					e["x"] = p.x
					e["z"] = p.y
					e["y"] = py + randf_range(-8.0, 8.0)
					e["hd"] = hd + PI
			"head":
				var ef2 := Vector2(sin(e["hd"]), cos(e["hd"]))
				var cur3 := Vector2(e["x"], e["z"]) + ef2 * 60.0 * dt
				e["x"] = cur3.x
				e["z"] = cur3.y
				var rr := _rel(e["x"], e["z"])
				e["fire_t"] -= dt
				if rr.y < 380.0 and rr.y > 40.0 and e["fire_t"] <= 0.0:
					e["fire_t"] = 0.12
					etracers.append({"x": e["x"], "y": e["y"], "z": e["z"], "t": 0.0})
					m.play("shot", -16.0)
					if absf(rr.x) < 16.0 and absf(e["y"] - py) < 12.0 and randf() < 0.3:
						_hurt(2.5 + level * 0.5)
				if rr.y < 12.0 or rr.length() > 900.0:
					e["mode"] = "behind"
					e["t2"] = 0.0
			"behind":
				e["t2"] += dt
				var cur4 := Vector2(wx, wz) + f * lerpf(-120.0, 30.0, clampf(e["t2"] / 3.0, 0.0, 1.0)) + r * 25.0
				e["x"] = cur4.x
				e["z"] = cur4.y
				e["y"] = py + 16.0
				e["hd"] = hd
				if e["t2"] > 3.0:
					e["mode"] = "chase"
					e["d"] = randf_range(120.0, 170.0)
					m.play("rpg", -14.0)
			"down":
				var fd := Vector2(sin(e["hd"]), cos(e["hd"]))
				var cur5 := Vector2(e["x"], e["z"]) + fd * SPEED * 0.85 * dt
				e["x"] = cur5.x
				e["z"] = cur5.y
				e["y"] -= (25.0 + 55.0 * e["t"]) * dt
				e["rot"] += 2.8 * dt
				e["smoke_t"] -= dt
				if e["smoke_t"] <= 0.0:
					e["smoke_t"] = 0.06
					smoke.append({"x": e["x"], "y": e["y"], "z": e["z"], "s": 7.0, "t": 0.0, "d": 2.2, "c": 0.08})
					fx.append({"x": e["x"], "y": e["y"], "z": e["z"], "s": 6.0, "t": 0.0, "d": 0.25})
				if e["t"] > 2.6 or e["y"] < 8.0:
					_explode_air(e["x"], e["y"], e["z"], 22.0)
					enemies.erase(e)
					kills += 1
					continue
		var new_rel := _rel(e["x"], e["z"])
		e["vx"] = (new_rel.x - old_rel.x) / maxf(dt, 0.001)
		if e["mode"] != "down" and e["hp"] < e["max"] * 0.5:
			e["smoke_t"] -= dt
			if e["smoke_t"] <= 0.0:
				e["smoke_t"] = 0.1
				smoke.append({"x": e["x"], "y": e["y"], "z": e["z"], "s": 5.0, "t": 0.0, "d": 1.8, "c": 0.15})

func _enemy_rect(e: Dictionary) -> Rect2:
	var p := proj(e["x"], e["y"], e["z"])
	if p.z <= 0.0:
		return Rect2()
	var tex: Texture2D = T["spit_front"] if e["mode"] == "head" else T["spit_rear"]
	var w := 11.0 * p.z * ES
	var h := w * tex.get_height() / tex.get_width()
	return Rect2(p.x - w * 0.5, p.y - h * 0.5, w, h)

func _reticle_view() -> Vector2:
	var a := Vector2(wx, wz) + _fwd() * AIM
	var p := proj(a.x, py, a.y)
	return Vector2(p.x, p.y)

func _enemy_on_reticle():
	var r := _reticle_view()
	for e in enemies:
		if e["mode"] in ["down", "behind"]:
			continue
		var rr := _enemy_rect(e)
		if rr.size.x > 0.0 and rr.grow_individual(-rr.size.x * 0.12, 4.0, -rr.size.x * 0.12, 4.0).has_point(r):
			return e
	return null

func _fire(e: Dictionary) -> void:
	muzzle = 0.05
	m.play("mg", -7.0)
	var r := _reticle_view() - Vector2(PAD, PAD)
	tracers.append({"a": _wing(-1), "b": r, "t": 0.0})
	tracers.append({"a": _wing(1), "b": r, "t": 0.0})
	e["hp"] -= 1.0
	fx.append({"x": e["x"] + randf_range(-3, 3), "y": e["y"] + randf_range(-1, 1), "z": e["z"], "s": 4.0, "t": 0.0, "d": 0.12})
	if e["hp"] <= 0.0 and e["mode"] != "down":
		e["mode"] = "down"
		e["t"] = 0.0
		m.play("boom", -6.0)
		_banner(L("أسقطت طيارة!", "Fighter down!"))

func _flak(dt: float, interval: float) -> void:
	flak_t -= dt
	if flak_t > 0.0:
		return
	flak_t = maxf(interval, 0.25) * randf_range(0.6, 1.3)
	var p := Vector2(wx, wz) + _fwd() * randf_range(160.0, 420.0) + _rgt() * randf_range(-75.0, 75.0)
	var fl := {"x": p.x, "y": py + randf_range(-35.0, 35.0), "z": p.y, "t": 0.0, "hit": false}
	flak.append(fl)
	fx.append({"x": fl["x"], "y": fl["y"], "z": fl["z"], "s": 16.0, "t": 0.0, "d": 0.35})
	smoke.append({"x": fl["x"], "y": fl["y"], "z": fl["z"], "s": 14.0, "t": 0.0, "d": 3.5, "c": 0.06, "still": true})
	m.play("boom", -18.0)

func drop_bomb() -> void:
	if bombs <= 0 or not running:
		return
	bombs -= 1
	var f := _fwd()
	bombs_air.append({"x": wx, "y": py - 3.0, "z": wz, "vx": f.x * SPEED, "vz": f.y * SPEED, "vy": 0.0})
	m.play("click", -4.0)

func _update_bombs(dt: float) -> void:
	for b in bombs_air.duplicate():
		b["x"] += b["vx"] * dt
		b["z"] += b["vz"] * dt
		b["vy"] -= GRAV * dt
		b["y"] += b["vy"] * dt
		if b["y"] <= 0.0:
			bombs_air.erase(b)
			_explode_ground(b["x"], b["z"], 1.0)
			if target_alive:
				var dist := Vector2(b["x"] - tx, b["z"] - tz).length()
				if dist < 42.0:
					target_alive = false
					_explode_ground(tx, tz, 2.4)
					_explode_ground(tx + 20.0, tz - 15.0, 1.6)
					shake = 1.0
				else:
					_banner(L("القنبلة جت بعيد %d م!", "Missed by %d m!") % int(dist))

func _explode_ground(x: float, z: float, s: float) -> void:
	ground_fx.append({"x": x, "z": z, "t": 0.0, "s": s})
	m.play("boom", -2.0)

func _explode_air(x: float, y: float, z: float, s: float) -> void:
	fx.append({"x": x, "y": y, "z": z, "s": s, "t": 0.0, "d": 0.8})
	smoke.append({"x": x, "y": y, "z": z, "s": s * 1.2, "t": 0.0, "d": 3.0, "c": 0.07})
	m.play("boom", -3.0)

func _hurt(d: float) -> void:
	health -= d
	hurt_a = minf(hurt_a + d / 12.0, 1.0)
	m.play("hurt", -8.0)
	if health <= 0.0 and running:
		health = 0.0
		var f := _fwd()
		_explode_air(wx + f.x * 4.0, py, wz + f.y * 4.0, 20.0)
		_fail(L("طيارتك اتضربت", "Your plane was shot down"))

func _fail(sub: String) -> void:
	running = false
	objective = "done"
	end_title.text = L("فشلت المهمة", "Mission Failed")
	end_sub.text = sub
	end_next.visible = false
	end_p.visible = true
	move_child(end_p, get_child_count() - 1)

func _win() -> void:
	running = false
	objective = "done"
	if level >= m.best_l:
		m.best_l = mini(level + 1, 3)
		m._save()
	end_title.text = L("نجحت المهمة!", "Mission Complete!")
	end_sub.text = L("دمرت الهدف ورجعت بسلام — المستوى %d", "Target destroyed and back safely — level %d") % level
	end_next.visible = level < 3
	if level >= 3:
		end_sub.text = L("أكملت معركة لندن بالكامل!", "You completed the Battle of London!")
	end_p.visible = true
	move_child(end_p, get_child_count() - 1)
	if not m.rated and not m.rate_shown:
		m.rate_shown = true
		m.rate_p.visible = true
		m.move_child(m.rate_p, m.get_child_count() - 1)

func _update_fx(dt: float) -> void:
	for arr in [fx, smoke]:
		for f in arr.duplicate():
			f["t"] += dt
			if f["t"] >= f["d"]:
				arr.erase(f)
	for s in smoke:
		if s.has("rise"):
			s["y"] += 14.0 * dt
		elif not s.has("still"):
			s["y"] += 3.0 * dt
	for arr2 in [tracers, etracers]:
		for tr in arr2.duplicate():
			tr["t"] += dt
			if tr["t"] > 0.09:
				arr2.erase(tr)
	for g in ground_fx:
		g["t"] += dt
	if not target_alive and running and randf() < dt * 10.0:
		smoke.append({"x": tx + randf_range(-15, 15), "y": randf_range(5, 30), "z": tz + randf_range(-15, 15), "s": 30.0, "t": 0.0, "d": 4.0, "c": 0.06, "rise": true})

# ---------------------------------------------------------------- input
func _input(ev: InputEvent) -> void:
	if not running:
		return
	if ev is InputEventScreenTouch:
		_touch(ev.index, ev.position, ev.pressed)
	elif ev is InputEventScreenDrag:
		if ev.index == joy_idx:
			_joy_set(ev.position)
	elif not DisplayServer.is_touchscreen_available():
		if ev is InputEventMouseButton and ev.button_index == MOUSE_BUTTON_LEFT:
			_touch(0, ev.position, ev.pressed)
		elif ev is InputEventMouseMotion and joy_idx == 0:
			_joy_set(ev.position)

func _touch(idx: int, pos: Vector2, pressed: bool) -> void:
	if pressed:
		if pos.distance_to(BOMB_C) < BOMB_R * 1.15:
			drop_bomb()
		elif pos.distance_to(JOY_C) < JOY_R * 1.7:
			joy_idx = idx
			_joy_set(pos)
		elif PAUSE_BTN.grow(8).has_point(pos):
			running = false
			pause_p.visible = true
			move_child(pause_p, get_child_count() - 1)
	elif idx == joy_idx:
		joy_idx = -1
		joy = Vector2.ZERO

func _joy_set(pos: Vector2) -> void:
	var v := (pos - JOY_C) / JOY_R
	if v.length() > 1.0:
		v = v.normalized()
	joy = v if v.length() > 0.12 else Vector2.ZERO

# ---------------------------------------------------------------- drawing
func _draw_sky(n: Node2D) -> void:
	# the sky panorama repeats (mirrored every other copy so the seams match) and slides with the heading
	var tex: Texture2D = T["sky"]
	var sw := view.size.x * 0.9
	var sh: float = sw * tex.get_height() / tex.get_width()
	var top := HORV - 0.67 * sh
	var off := -fposmod(chd / TAU * sw * 4.0, sw * 2.0)
	var x := off
	var i := int(floor(-off / sw))
	while x < view.size.x + sw:
		var flip := (int(floor((x - off) / sw + 0.5)) % 2) == 1
		if flip:
			n.draw_set_transform(Vector2(x + sw, top), 0.0, Vector2(-1, 1))
			n.draw_texture_rect(tex, Rect2(0, 0, sw, sh), false)
			n.draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
		else:
			n.draw_texture_rect(tex, Rect2(x, top, sw, sh), false)
		x += sw
	if top > 0.0:
		n.draw_rect(Rect2(0, 0, view.size.x, top + 2.0), Color(0.16, 0.14, 0.15))

func _draw_air() -> void:
	var boom: Texture2D = T["boom"]
	var g := proj(tx, 0.0, tz)
	if g.z > F / 3000.0:
		var dz := F / g.z
		var r := 40.0 * g.z
		var squash := clampf(camy / maxf(dz, 1.0), 0.06, 1.0)
		var pulse := 0.5 + 0.5 * sin(Time.get_ticks_msec() / 200.0)
		var col := Color(0.95, 0.1, 0.05, 0.9) if target_alive else Color(0.2, 0.15, 0.1, 0.7)
		air.draw_set_transform(Vector2(g.x, g.y), 0.0, Vector2(1.0, squash))
		if target_alive:
			air.draw_circle(Vector2.ZERO, r * (1.0 + pulse * 0.25), Color(0.95, 0.08, 0.03, 0.18))
		air.draw_arc(Vector2.ZERO, r, 0, TAU, 48, col, maxf(3.0 / squash, 3.0), true)
		air.draw_arc(Vector2.ZERO, r * 0.55, 0, TAU, 40, col, maxf(2.0 / squash, 2.0), true)
		air.draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
		if target_alive and dz < 2500.0:
			var top := Vector2(g.x, g.y - 30.0 - pulse * 8.0)
			air.draw_colored_polygon(PackedVector2Array([top, top + Vector2(-14, -22), top + Vector2(14, -22)]), Color(0.95, 0.1, 0.05))
	for gf in ground_fx:
		var gp := proj(gf["x"], 0.0, gf["z"])
		if gp.z <= 0.0:
			continue
		var k: float = clampf(gf["t"] / 1.2, 0.0, 1.0)
		var sz: float = 70.0 * gf["s"] * gp.z * (0.6 + k * 0.6)
		var hgt: float = sz * boom.get_height() / boom.get_width()
		air.draw_texture_rect(boom, Rect2(Vector2(gp.x, gp.y) - Vector2(sz * 0.5, hgt * 0.8), Vector2(sz, hgt)), false, Color(0.12, 0.1, 0.08, 0.85 * (1.0 - k * 0.5)))
	var items: Array = []
	for e in enemies:
		items.append([_depth(e["x"], e["z"]), 0, e])
	for s in smoke:
		items.append([_depth(s["x"], s["z"]), 1, s])
	for b in bombs_air:
		items.append([_depth(b["x"], b["z"]), 2, b])
	for c in clouds:
		items.append([_depth(c["x"], c["z"]), 3, c])
	items.sort_custom(func(a, b): return a[0] > b[0])
	for it in items:
		if it[0] < 2.0:
			continue
		match it[1]:
			0:
				var e: Dictionary = it[2]
				var rr := _enemy_rect(e)
				if rr.size.x <= 0.0:
					continue
				var tex: Texture2D = T["spit_front"] if e["mode"] == "head" else T["spit_rear"]
				var ang: float = clampf(e["vx"] * 0.012, -0.7, 0.7) + e["rot"]
				var haze := clampf(it[0] / 900.0, 0.0, 0.5)
				var c := Color(1, 1, 1).lerp(Color(1.0, 0.82, 0.6), haze)
				air.draw_set_transform(rr.get_center(), ang, Vector2.ONE)
				air.draw_texture_rect(tex, Rect2(-rr.size * 0.5, rr.size), false, c)
				air.draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
			1:
				var s: Dictionary = it[2]
				var p := proj(s["x"], s["y"], s["z"])
				if p.z <= 0.0:
					continue
				var k2: float = s["t"] / s["d"]
				var sz2: float = s["s"] * p.z * (0.7 + k2 * 1.2)
				var hh: float = sz2 * boom.get_height() / boom.get_width()
				air.draw_texture_rect(boom, Rect2(Vector2(p.x, p.y) - Vector2(sz2, hh) * 0.5, Vector2(sz2, hh)), false, Color(s["c"], s["c"], s["c"], 0.75 * (1.0 - k2)))
			2:
				var b: Dictionary = it[2]
				var bp := proj(b["x"], b["y"], b["z"])
				if bp.z <= 0.0:
					continue
				var bw := maxf(1.6 * bp.z * ES, 10.0)
				var bh: float = bw * T["bomb"].get_height() / T["bomb"].get_width()
				air.draw_texture_rect(T["bomb"], Rect2(Vector2(bp.x, bp.y) - Vector2(bw, bh) * 0.5, Vector2(bw, bh)), false)
			3:
				var cl: Dictionary = it[2]
				var cp := proj(cl["x"], cl["y"], cl["z"])
				if cp.z <= 0.0:
					continue
				var dz2: float = it[0]
				var ca := clampf((dz2 - 25.0) / 140.0, 0.0, 1.0) * clampf((1150.0 - dz2) / 250.0, 0.0, 1.0)
				if ca <= 0.0:
					continue
				var ct: Texture2D = T["cloud%d" % cl["i"]]
				var cw: float = cl["s"] * cp.z
				var ch: float = cw * ct.get_height() / ct.get_width()
				air.draw_texture_rect(ct, Rect2(Vector2(cp.x, cp.y) - Vector2(cw, ch) * 0.5, Vector2(cw, ch)), false, Color(1, 0.97, 0.92, ca * 0.92))

func _draw_fx() -> void:
	var boom: Texture2D = T["boom"]
	for f in fx:
		var p := proj(f["x"], f["y"], f["z"])
		if p.z <= 0.0:
			continue
		var k: float = f["t"] / f["d"]
		var sz: float = f["s"] * p.z * (0.6 + k * 0.8) * 1.3
		var hh: float = sz * boom.get_height() / boom.get_width()
		fxl.draw_texture_rect(boom, Rect2(Vector2(p.x, p.y) - Vector2(sz, hh) * 0.5, Vector2(sz, hh)), false, Color(1, 1, 1, pow(1.0 - k, 1.3)))
	for gf in ground_fx:
		var gp := proj(gf["x"], 0.0, gf["z"])
		if gp.z <= 0.0 or gf["t"] > 1.0:
			continue
		var k3: float = gf["t"]
		var s3: float = 80.0 * gf["s"] * gp.z * (0.5 + k3)
		var h3: float = s3 * boom.get_height() / boom.get_width()
		fxl.draw_texture_rect(boom, Rect2(Vector2(gp.x, gp.y) - Vector2(s3 * 0.5, h3 * 0.85), Vector2(s3, h3)), false, Color(1, 1, 1, 1.0 - k3))
	var fp := Vector2(wx, wz) + _fwd() * 6.0
	var b := proj(fp.x, py, fp.y)
	for et in etracers:
		var a := proj(et["x"], et["y"], et["z"])
		if a.z <= 0.0 or b.z <= 0.0:
			continue
		var k4: float = et["t"] / 0.09
		var p1 := Vector2(a.x, a.y).lerp(Vector2(b.x, b.y), clampf(k4 * 1.2 - 0.2, 0.0, 1.0))
		var p2 := Vector2(a.x, a.y).lerp(Vector2(b.x, b.y), clampf(k4 * 1.2 + 0.1, 0.0, 1.0))
		fxl.draw_line(p1, p2, Color(1, 0.55, 0.3, 0.9), 2.5)

func _plane_geom() -> Dictionary:
	var p := proj(wx, py, wz)
	var w := 400.0
	var h: float = w * T["stuka"].get_height() / T["stuka"].get_width()
	var c := Vector2(p.x, p.y) - Vector2(PAD, PAD) + Vector2(0, 95)
	return {"c": c, "w": w, "h": h, "ang": turn * 0.6}

func _wing(side: int) -> Vector2:
	var g := _plane_geom()
	return g["c"] + Vector2(side * g["w"] * 0.2, -g["h"] * 0.12).rotated(g["ang"])

func _draw_plane() -> void:
	if health <= 0.0:
		return
	var g := _plane_geom()
	plane_l.draw_set_transform(g["c"], g["ang"], Vector2.ONE)
	plane_l.draw_texture_rect(T["stuka"], Rect2(-g["w"] * 0.5, -g["h"] * 0.5, g["w"], g["h"]), false)
	plane_l.draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)

func _draw_plane_fx() -> void:
	for tr in tracers:
		var k: float = tr["t"] / 0.09
		var a: Vector2 = tr["a"]
		var b: Vector2 = tr["b"]
		plane_fx.draw_line(a.lerp(b, clampf(k * 1.3 - 0.3, 0.0, 1.0)), a.lerp(b, clampf(k * 1.3 + 0.1, 0.0, 1.0)), Color(1, 0.75, 0.35, 0.9), 3.0)
	if muzzle > 0.0:
		for s in [-1, 1]:
			var wp := _wing(s)
			plane_fx.draw_texture_rect(T["boom"], Rect2(wp - Vector2(36, 26), Vector2(72, 52)), false)

func _draw_reticle() -> void:
	if brief.visible:
		return
	var r := _reticle_view() - Vector2(PAD, PAD)
	var sz := 150.0
	var c := Color(1, 0.55, 0.45) if firing else Color(1, 1, 1, 0.9)
	ret_l.draw_texture_rect(T["reticle"], Rect2(r - Vector2(sz, sz) * 0.5, Vector2(sz, sz)), false, c)

func _radar_pt(x: float, z: float) -> Vector2:
	var rp := _rel(x, z)
	var v := Vector2(rp.x, -rp.y) / RADAR_RANGE * RADAR_R
	if v.length() > RADAR_R - 6.0:
		v = v.normalized() * (RADAR_R - 6.0)
	return RADAR_C + v

func _clip_circle(a: Vector2, b: Vector2, c: Vector2, r: float) -> Array:
	var d := b - a
	var f := a - c
	var A := d.dot(d)
	var B := 2.0 * f.dot(d)
	var C := f.dot(f) - r * r
	var disc := B * B - 4.0 * A * C
	if disc < 0.0 or A == 0.0:
		return []
	var s := sqrt(disc)
	var t1 := clampf((-B - s) / (2.0 * A), 0.0, 1.0)
	var t2 := clampf((-B + s) / (2.0 * A), 0.0, 1.0)
	if t2 <= t1:
		return []
	return [a + d * t1, a + d * t2]

func _draw_radar() -> void:
	var font: Font = m.font
	var c := RADAR_C
	hud.draw_circle(c, RADAR_R + 6, Color(0.55, 0.42, 0.18, 0.95))
	hud.draw_circle(c, RADAR_R, Color(0.03, 0.09, 0.05, 0.88))
	hud.draw_arc(c, RADAR_R, 0, TAU, 64, Color(0.9, 0.75, 0.4), 2.0, true)
	hud.draw_arc(c, RADAR_R * 0.5, 0, TAU, 48, Color(0.3, 0.8, 0.4, 0.35), 1.0, true)
	hud.draw_line(c + Vector2(-RADAR_R, 0), c + Vector2(RADAR_R, 0), Color(0.3, 0.8, 0.4, 0.25), 1.0)
	hud.draw_line(c + Vector2(0, -RADAR_R), c + Vector2(0, RADAR_R), Color(0.3, 0.8, 0.4, 0.25), 1.0)
	var sa := fposmod(t_all * 2.2, TAU)
	for i in 10:
		var a := sa - i * 0.06
		hud.draw_line(c, c + Vector2(cos(a), sin(a)) * RADAR_R, Color(0.35, 1.0, 0.45, 0.22 * (1.0 - i / 10.0)), 2.0)
	# coastline
	var rp1 := _rel(wx - 6000.0, COAST_Z)
	var rp2 := _rel(wx + 6000.0, COAST_Z)
	var q1 := c + Vector2(rp1.x, -rp1.y) / RADAR_RANGE * RADAR_R
	var q2 := c + Vector2(rp2.x, -rp2.y) / RADAR_RANGE * RADAR_R
	var seg := _clip_circle(q1, q2, c, RADAR_R - 2.0)
	if seg.size() == 2:
		hud.draw_line(seg[0], seg[1], Color(0.85, 0.75, 0.5, 0.75), 2.0)
	if target_alive:
		var tp := _radar_pt(tx, tz)
		var pulse := 0.5 + 0.5 * sin(Time.get_ticks_msec() / 200.0)
		hud.draw_rect(Rect2(tp - Vector2(6, 6), Vector2(12, 12)), Color(1, 0.15, 0.08, 0.7 + 0.3 * pulse))
	for e in enemies:
		if e["mode"] == "down":
			continue
		hud.draw_circle(_radar_pt(e["x"], e["z"]), 5.0, Color(1, 0.25, 0.2))
	if objective == "home":
		hud.draw_circle(_radar_pt(wx, COAST_Z - 2000.0), 6.0, Color(0.4, 0.8, 1.0))
	hud.draw_colored_polygon(PackedVector2Array([c + Vector2(0, -9), c + Vector2(-7, 7), c + Vector2(7, 7)]), Color(1, 0.95, 0.7))
	hud.draw_string(font, c + Vector2(-RADAR_R, RADAR_R + 28), L("رادار", "RADAR"), HORIZONTAL_ALIGNMENT_CENTER, RADAR_R * 2, 18, Color(0.95, 0.85, 0.55))

func _draw_hud() -> void:
	if brief.visible:
		return
	var font: Font = m.font
	var hb := Rect2(24, 22, 300, 26)
	hud.draw_rect(hb.grow(3), Color(0, 0, 0, 0.6))
	var hc := Color(0.25, 0.8, 0.3) if health > 50 else (Color(0.95, 0.75, 0.15) if health > 25 else Color(0.95, 0.15, 0.1))
	hud.draw_rect(Rect2(hb.position, Vector2(hb.size.x * health / 100.0, hb.size.y)), hc)
	hud.draw_string(font, Vector2(30, 76), L("الصحة %d", "Health %d") % int(health), HORIZONTAL_ALIGNMENT_LEFT, -1, 22, Color(1, 1, 1))
	var deg := int(fposmod(rad_to_deg(hd), 360.0))
	hud.draw_string(font, Vector2(30, 106), L("الاتجاه %d°", "Heading %d°") % deg, HORIZONTAL_ALIGNMENT_LEFT, -1, 20, Color(0.95, 0.88, 0.65))
	_draw_radar()
	var cs := BOMB_R * 2.1
	var ready := bombs > 0 and objective == "target"
	hud.draw_texture_rect(T["btn_cannon"], Rect2(BOMB_C - Vector2(cs, cs) * 0.5, Vector2(cs, cs)), false, Color(1, 1, 1) if ready else Color(0.55, 0.55, 0.55, 0.9))
	var lab := L("قنبلة × %d", "BOMB × %d") % bombs
	var cw := font.get_string_size(lab, HORIZONTAL_ALIGNMENT_LEFT, -1, 24).x
	var cb := Rect2(BOMB_C + Vector2(-cw * 0.5 - 12, cs * 0.5 - 18), Vector2(cw + 24, 36))
	hud.draw_rect(cb, Color(0.12, 0.1, 0.07, 0.92))
	hud.draw_rect(cb, Color(0.8, 0.62, 0.3), false, 2.0)
	hud.draw_string(font, cb.position + Vector2(12, 27), lab, HORIZONTAL_ALIGNMENT_LEFT, -1, 24, Color(1, 0.88, 0.55))
	var ds := JOY_R * 2.15
	hud.draw_texture_rect(T["btn_dpad"], Rect2(JOY_C + joy * 7.0 - Vector2(ds, ds) * 0.5, Vector2(ds, ds)), false, Color(1.15, 1.1, 1.0) if joy != Vector2.ZERO else Color(1, 1, 1, 0.95))
	hud.draw_rect(PAUSE_BTN, Color(0, 0, 0, 0.45))
	hud.draw_rect(Rect2(PAUSE_BTN.position + Vector2(24, 14), Vector2(8, 28)), Color(1, 0.92, 0.7))
	hud.draw_rect(Rect2(PAUSE_BTN.position + Vector2(40, 14), Vector2(8, 28)), Color(1, 0.92, 0.7))
