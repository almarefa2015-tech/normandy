extends Control
# London 1940 — chase-camera bombing mission (dogfight, flak, target, return home)

const W := 1280.0
const H := 720.0
const F := 640.0            # focal length in pixels
const PAD := 260.0          # extra border so the view can roll without showing edges
const HORV := 290.0 + PAD   # horizon line in view coordinates
const CXV := 640.0 + PAD
const SPEED := 120.0        # forward speed m/s
const GRAV := 12.0          # bomb gravity (arcade, slow fall so the target stays in view)
const AHEAD := 16.0         # player plane distance in front of the camera
const AIM := 170.0          # gun convergence distance in front of the plane
const ES := 1.8             # aircraft display scale (arcade readability)
const JOY_C := Vector2(165.0, H - 165.0)
const JOY_R := 100.0
const BOMB_C := Vector2(W - 140.0, H - 150.0)
const BOMB_R := 92.0
const PAUSE_BTN := Rect2(W - 86.0, 14.0, 70.0, 56.0)

var m          # main.gd node (font, sounds, texts, save)
var level := 1
var T := {}

var view: Control
var gmat: ShaderMaterial
var air: Node2D
var fxl: Node2D
var plane_l: Node2D
var plane_fx: Node2D
var ret_l: Node2D
var hud: Node2D
var shade: ColorRect
var hurt: ColorRect
var top_l: Label
var info_l: Label
var banner: Label
var brief: Control
var brief_draw: Control
var pause_p: Control
var end_p: Control
var end_title: Label
var end_sub: Label
var end_next: Button

var phase := "brief"
var pt := 0.0
var running := false
var camz := 0.0
var camx := 0.0
var camy := 101.0
var px := 0.0
var py := 95.0
var bank := 0.0
var health := 100.0
var bombs := 3
var mg_cd := 0.0
var firing := false
var muzzle := 0.0
var shake := 0.0
var hurt_a := 0.0
var joy := Vector2.ZERO
var joy_idx := -1

var enemies: Array = []
var flak: Array = []
var smoke: Array = []
var fx: Array = []
var tracers: Array = []
var etracers: Array = []
var bombs_air: Array = []
var ground_fx: Array = []
var to_spawn := 0
var spawn_t := 0.0
var head_t := 9.0
var flak_t := 0.0

var land_start := 1e9
var land_end := 1e9
var city_start := 1e9
var city_end := 1e9
var tx := 0.0
var tz := 1e9
var target_alive := true
var target_t := 0.0

# ---------------------------------------------------------------- setup
func setup(main_node, lvl: int) -> void:
	m = main_node
	level = lvl
	size = Vector2(W, H)
	for n in ["stuka", "spit_rear", "spit_front", "bomb", "boom", "reticle", "btn_dpad", "btn_cannon", "map"]:
		T[n] = m.T[n] if m.T.has(n) else load("res://assets/art/" + n + ".png")
	for n in ["city", "sea", "fields", "sky"]:
		T[n] = load("res://assets/art/" + n + ".jpg")

	var bg := ColorRect.new()
	bg.color = Color(0.1, 0.08, 0.06)
	bg.size = Vector2(W, H)
	add_child(bg)
	view = Control.new()
	view.position = Vector2(-PAD, -PAD)
	view.size = Vector2(W + PAD * 2, H + PAD * 2)
	view.pivot_offset = view.size * 0.5
	add_child(view)
	var sky := TextureRect.new()
	sky.texture = T["sky"]
	sky.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	var sw := view.size.x
	var sh: float = sw * T["sky"].get_height() / T["sky"].get_width()
	sky.size = Vector2(sw, sh)
	sky.position = Vector2(0, HORV - 0.67 * sh)
	view.add_child(sky)
	var ground := ColorRect.new()
	ground.size = view.size
	gmat = ShaderMaterial.new()
	gmat.shader = load("res://ground.gdshader")
	gmat.set_shader_parameter("sea_tex", T["sea"])
	gmat.set_shader_parameter("land_tex", T["fields"])
	gmat.set_shader_parameter("city_tex", T["city"])
	gmat.set_shader_parameter("rect_size", view.size)
	gmat.set_shader_parameter("hor", HORV)
	gmat.set_shader_parameter("cx", CXV)
	gmat.set_shader_parameter("focal", F)
	ground.material = gmat
	view.add_child(ground)
	air = Node2D.new()
	view.add_child(air)
	air.draw.connect(_draw_air)
	fxl = _layer(view, true)
	fxl.draw.connect(_draw_fx)

	plane_l = Node2D.new()
	add_child(plane_l)
	plane_l.draw.connect(_draw_plane)
	plane_fx = _layer(self, true)
	plane_fx.draw.connect(_draw_plane_fx)
	ret_l = _layer(self, true)
	ret_l.draw.connect(_draw_reticle)
	hud = Node2D.new()
	add_child(hud)
	hud.draw.connect(_draw_hud)
	hurt = ColorRect.new()
	hurt.color = Color(0.7, 0, 0, 0)
	hurt.size = Vector2(W, H)
	hurt.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(hurt)
	top_l = _label("", 26, Color(1, 0.93, 0.7), Vector2(W * 0.5 - 330, 14), 660)
	info_l = _label("", 22, Color(1, 0.85, 0.5), Vector2(W * 0.5 - 330, 52), 660)
	banner = _label("", 46, Color(1, 0.9, 0.55), Vector2(0, H * 0.2), W)
	banner.modulate.a = 0.0
	_build_brief()
	_build_pause()
	_build_end()
	shade = ColorRect.new()
	shade.color = Color(0, 0, 0, 0)
	shade.size = Vector2(W, H)
	shade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(shade)
	_reset()
	brief.visible = true

func _layer(parent: Node, additive: bool) -> Node2D:
	var n := Node2D.new()
	if additive:
		var mt := CanvasItemMaterial.new()
		mt.blend_mode = CanvasItemMaterial.BLEND_MODE_ADD
		n.material = mt
	parent.add_child(n)
	return n

func _label(txt: String, sz: int, col: Color, pos: Vector2, w: float) -> Label:
	var l := Label.new()
	l.text = txt
	l.add_theme_font_size_override("font_size", sz)
	l.add_theme_color_override("font_color", col)
	l.add_theme_color_override("font_outline_color", Color.BLACK)
	l.add_theme_constant_override("outline_size", 8)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.position = pos
	l.size = Vector2(w, sz * 1.6)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(l)
	return l

func L(a: String, e: String) -> String:
	return m.L(a, e)

func _panel() -> Control:
	var c := Control.new()
	c.size = Vector2(W, H)
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.62)
	dim.size = Vector2(W, H)
	c.add_child(dim)
	add_child(c)
	c.visible = false
	return c

# ---------------------------------------------------------------- briefing
const MAP_REG := Rect2(90, 85, 560, 315)   # region of map.jpg around the Channel

func _map_pt(p: Vector2) -> Vector2:
	return (p - MAP_REG.position) / MAP_REG.size * Vector2(W, H)

func _build_brief() -> void:
	brief = Control.new()
	brief.size = Vector2(W, H)
	add_child(brief)
	var at := AtlasTexture.new()
	at.atlas = T["map"]
	at.region = MAP_REG
	var tr := TextureRect.new()
	tr.texture = at
	tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	tr.size = Vector2(W, H)
	brief.add_child(tr)
	brief_draw = Control.new()
	brief_draw.size = Vector2(W, H)
	brief_draw.mouse_filter = Control.MOUSE_FILTER_IGNORE
	brief_draw.draw.connect(_draw_brief)
	brief.add_child(brief_draw)
	var px0 := W * 0.52
	var head: Label = m._plabel(brief, L("المهمة: الهجوم على لندن 1940", "Mission: The Attack on London 1940"), 34, 128, Color(1, 0.86, 0.5))
	head.position = Vector2(px0, 128)
	head.size = Vector2(560, 60)
	var n := level
	var lines := [
		L("• اعبر القنال وأسقط طيارة إنجليزية واحدة بالرشاش" if n == 1 else "• اعبر القنال وأسقط %d طيارات إنجليزية بالرشاش" % n, "• Cross the Channel and shoot down %d British fighter%s" % [n, "" if n == 1 else "s"]),
		L("• اتجه للمبنى المعلّم بالأحمر في لندن", "• Fly to the building marked in red in London"),
		L("• ارمي القنبلة قبل ما توصل فوق الهدف بشوية عشان تيجي عليه بالظبط", "• Release the bomb a little before you reach the target to hit it dead on"),
		L("• تفادى نيران المدافع الأرضية", "• Dodge the anti-aircraft fire"),
		L("• ارجع للقاعدة بسلام", "• Return to base safely"),
	]
	var y := 200.0
	var d := 0.4
	for s in lines:
		var l: Label = m._plabel(brief, s, 22, y, Color(0.98, 0.93, 0.82))
		l.position = Vector2(px0, y)
		l.size = Vector2(560, 60)
		l.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT if m.AR else HORIZONTAL_ALIGNMENT_LEFT
		l.visible_ratio = 0.0
		var tw := create_tween()
		tw.tween_interval(d)
		tw.tween_property(l, "visible_ratio", 1.0, 0.7)
		d += 0.65
		y += 68.0
	var b: Button = m._btn(brief, L("انطلق", "Take Off"), Vector2(px0 + 140, 550), Vector2(280, 84), _go, 36)
	m._btn(brief, L("الخريطة", "Map"), Vector2(30, 24), Vector2(190, 64), _exit, 26)
	b.modulate.a = 0.0
	var tw2 := create_tween()
	tw2.tween_interval(d)
	tw2.tween_property(b, "modulate:a", 1.0, 0.5)

func _draw_brief() -> void:
	var lon := _map_pt(Vector2(250, 245))
	var start := _map_pt(Vector2(330, 312))
	var pulse := 0.5 + 0.5 * sin(Time.get_ticks_msec() / 250.0)
	# panel
	var pr := Rect2(W * 0.52 - 24, 112, 600, 540)
	brief_draw.draw_rect(pr, Color(0.08, 0.06, 0.04, 0.82))
	brief_draw.draw_rect(pr, Color(0.85, 0.65, 0.3), false, 3.0)
	brief_draw.draw_rect(pr.grow(-8), Color(0.85, 0.65, 0.3, 0.4), false, 1.0)
	# route (dashed) from France to London
	var segs := 14
	for i in segs:
		if i % 2 == 0:
			var a := start.lerp(lon, float(i) / segs)
			var bb := start.lerp(lon, float(i + 1) / segs)
			brief_draw.draw_line(a, bb, Color(0.75, 0.1, 0.05, 0.9), 4.0, true)
	brief_draw.draw_circle(start, 8, Color(0.2, 0.2, 0.2))
	brief_draw.draw_circle(lon, 26 + pulse * 14, Color(0.85, 0.08, 0.03, 0.25 * (1.0 - pulse) + 0.1))
	brief_draw.draw_arc(lon, 22, 0, TAU, 40, Color(0.85, 0.08, 0.03), 4.0, true)
	brief_draw.draw_line(lon + Vector2(-30, 0), lon + Vector2(30, 0), Color(0.85, 0.08, 0.03), 3.0)
	brief_draw.draw_line(lon + Vector2(0, -30), lon + Vector2(0, 30), Color(0.85, 0.08, 0.03), 3.0)
	brief_draw.draw_string(m.font, lon + Vector2(-60, -40), L("الهدف", "TARGET"), HORIZONTAL_ALIGNMENT_CENTER, 120, 24, Color(0.75, 0.05, 0.02))

func _go() -> void:
	brief.visible = false
	running = true
	phase = "sea"
	pt = 0.0
	_banner(L("عبور القنال", "Crossing the Channel"))

func _build_pause() -> void:
	pause_p = _panel()
	m._plabel(pause_p, L("استراحة", "Paused"), 64, 170)
	m._btn(pause_p, L("كمّل", "Continue"), Vector2(W * 0.5 - 150, 300), Vector2(300, 84), func(): pause_p.visible = false; running = true)
	m._btn(pause_p, L("الخريطة", "Map"), Vector2(W * 0.5 - 150, 410), Vector2(300, 84), _exit)

func _build_end() -> void:
	end_p = _panel()
	end_title = m._plabel(end_p, "", 66, 140)
	end_sub = m._plabel(end_p, "", 28, 240, Color(1, 0.95, 0.85))
	end_next = m._btn(end_p, L("المستوى التالي", "Next Level"), Vector2(W * 0.5 - 170, 330), Vector2(340, 84), func(): _restart(level + 1))
	m._btn(end_p, L("إعادة", "Retry"), Vector2(W * 0.5 - 170, 432), Vector2(340, 76), func(): _restart(level))
	m._btn(end_p, L("الخريطة", "Map"), Vector2(W * 0.5 - 170, 526), Vector2(340, 76), _exit)

func _restart(l: int) -> void:
	var nl = load("res://london.gd").new()
	m.add_child(nl)
	nl.setup(m, l)
	queue_free()

func _exit() -> void:
	m._show_map()
	queue_free()

# ---------------------------------------------------------------- state
func _reset() -> void:
	camz = 0.0
	camx = 0.0
	px = 0.0
	py = 95.0
	camy = py + 6.0
	health = 100.0
	bombs = 3
	land_start = 1e9
	land_end = 1e9
	city_start = 1e9
	city_end = 1e9
	tz = 1e9
	target_alive = true

func _banner(txt: String) -> void:
	banner.text = txt
	banner.modulate.a = 1.0
	var tw := create_tween()
	tw.tween_interval(1.8)
	tw.tween_property(banner, "modulate:a", 0.0, 0.6)

func _fade(cb: Callable) -> void:
	running = false
	var tw := create_tween()
	tw.tween_property(shade, "color:a", 1.0, 0.45)
	tw.tween_callback(cb)
	tw.tween_callback(func(): running = true)
	tw.tween_property(shade, "color:a", 0.0, 0.45)

func proj(x: float, y: float, z: float) -> Vector3:
	var dz := z - camz
	if dz < 2.0:
		return Vector3(-99999, -99999, 0)
	var k := F / dz
	return Vector3(CXV + (x - camx) * k, HORV + (camy - y) * k, k)

# ---------------------------------------------------------------- update
func _process(delta: float) -> void:
	var dt := minf(delta, 0.05)
	if brief.visible:
		brief_draw.queue_redraw()
	if running:
		_update(dt)
	_update_fx(dt)
	view.rotation = -bank * 0.14
	view.position = Vector2(-PAD, -PAD) + Vector2(randf_range(-1, 1), randf_range(-1, 1)) * shake * 12.0
	shake = maxf(shake - dt * 2.5, 0.0)
	muzzle = maxf(muzzle - dt, 0.0)
	hurt_a = maxf(hurt_a - dt * 1.5, 0.0)
	hurt.color.a = hurt_a * 0.45
	gmat.set_shader_parameter("cam", Vector2(camx, camz))
	gmat.set_shader_parameter("cam_h", camy)
	gmat.set_shader_parameter("land_start", land_start)
	gmat.set_shader_parameter("land_end", land_end)
	gmat.set_shader_parameter("city_start", city_start)
	gmat.set_shader_parameter("city_end", city_end)
	for n in [air, fxl, plane_l, plane_fx, ret_l, hud]:
		n.queue_redraw()

func _update(dt: float) -> void:
	pt += dt
	camz += SPEED * dt
	# flight controls
	px += joy.x * 48.0 * dt
	py = clampf(py - joy.y * 30.0 * dt, 65.0, 150.0)
	bank = lerpf(bank, joy.x, minf(dt * 4.0, 1.0))
	camx = lerpf(camx, px, minf(dt * 3.5, 1.0))
	camx = clampf(camx, px - 14.0, px + 14.0)
	camy = lerpf(camy, py + 6.0, minf(dt * 2.2, 1.0))
	# phases
	match phase:
		"sea":
			land_start = camz + 4000.0
			if pt > 3.0:
				phase = "fight"
				pt = 0.0
				to_spawn = level
				spawn_t = 0.5
				head_t = randf_range(8.0, 11.0) - level
				_banner(L("طيارات العدو! أسقطهم", "Enemy fighters! Shoot them down"))
		"fight":
			land_start = camz + 4000.0
			spawn_t -= dt
			if to_spawn > 0 and spawn_t <= 0.0:
				_spawn_enemy()
				to_spawn -= 1
				spawn_t = 1.6
			if to_spawn == 0 and enemies.is_empty():
				phase = "approach"
				pt = 0.0
				land_start = camz + 900.0
				city_start = land_start + 1500.0
				_banner(L("اتجه للهدف — خلي بالك من المدافع الأرضية", "Head for the target — watch the flak"))
		"approach":
			_flak(dt, 1.25 - level * 0.2)
			if camz > city_start - 300.0:
				phase = "city"
				pt = 0.0
				tz = city_start + 1300.0
				tx = camx + randf_range(-60.0, 60.0)
				_banner(L("الهدف معلّم بالأحمر — ارمي القنبلة!", "Target marked in red — drop the bomb!"))
		"city":
			_flak(dt, 0.75 - level * 0.12)
			if not target_alive:
				target_t += dt
				if target_t > 3.0:
					_go_home()
			elif camz > tz + 160.0 and bombs_air.is_empty():
				if bombs > 0:
					_banner(L("فاتك الهدف! بنلف ونرجعله", "Missed it! Coming around again"))
					_fade(_reapproach)
				else:
					_fail(L("القنابل خلصت والهدف لسه سليم", "Out of bombs — the target survived"))
		"return":
			if camz < land_end:
				_flak(dt, 1.0 - level * 0.15)
			if camz > land_end + 600.0:
				_win()
	# guns: fire automatically when the reticle is on an enemy
	mg_cd -= dt
	firing = false
	var on = _enemy_on_reticle()
	if on != null:
		firing = true
		if mg_cd <= 0.0:
			mg_cd = 0.08
			_fire(on)
	_update_enemies(dt)
	_update_bombs(dt)
	# flak bursts we fly through
	var pz := camz + AHEAD
	for f in flak.duplicate():
		if not f["hit"] and f["z"] <= pz and f["z"] > pz - SPEED * dt * 1.5:
			f["hit"] = true
			if Vector2(f["x"] - px, f["y"] - py).length() < 22.0:
				_hurt(9.0 + level)
				shake = maxf(shake, 0.9)
		if f["z"] < camz:
			flak.erase(f)
	_status()

func _status() -> void:
	top_l.text = L("لندن 1940 — المستوى %d", "London 1940 — Level %d") % level
	match phase:
		"sea", "fight":
			var n := enemies.size() + to_spawn
			info_l.text = L("طيارات العدو: %d", "Enemy fighters: %d") % n if phase == "fight" else ""
		"approach":
			info_l.text = L("المسافة للهدف: %d م", "Distance to target: %d m") % int(maxf(city_start + 1300.0 - camz, 0.0))
		"city":
			info_l.text = (L("المسافة للهدف: %d م", "Distance to target: %d m") % int(maxf(tz - camz, 0.0))) if target_alive else L("تم تدمير الهدف!", "Target destroyed!")
		"return":
			info_l.text = L("ارجع للقاعدة: %d م", "Return to base: %d m") % int(maxf(land_end + 600.0 - camz, 0.0))

func _reapproach() -> void:
	camz = tz - 1700.0
	px = tx + randf_range(-70.0, 70.0)
	camx = px
	flak.clear()
	smoke.clear()

func _go_home() -> void:
	phase = "return"
	pt = 0.0
	_banner(L("تم تدمير الهدف! ارجع للقاعدة", "Target destroyed! Return to base"))
	_fade(func():
		camz = 0.0
		city_start = -1e9
		city_end = 900.0
		land_start = -1e9
		land_end = 1900.0
		tz = 1e9
		flak.clear()
		smoke.clear()
		ground_fx.clear())

func _spawn_enemy() -> void:
	var e := {
		"x": px + randf_range(-80.0, 80.0), "y": py + randf_range(-15.0, 25.0),
		"bx": px, "by": py, "d": 420.0, "z": camz + 420.0, "dt": randf_range(110.0, 160.0),
		"ph": randf() * TAU, "hp": 12.0 + level * 3.0, "max": 12.0 + level * 3.0,
		"mode": "rear", "t": 0.0, "rot": 0.0, "smoke_t": 0.0, "fire_t": 0.0, "vx": 0.0,
	}
	enemies.append(e)

func _update_enemies(dt: float) -> void:
	head_t -= dt
	for e in enemies.duplicate():
		e["t"] += dt
		var ox: float = e["x"]
		match e["mode"]:
			"rear":
				e["bx"] = move_toward(e["bx"], px, (8.0 + level * 3.0) * dt)
				e["by"] = move_toward(e["by"], py, 6.0 * dt)
				var agg := 0.4 + level * 0.12
				e["x"] = e["bx"] + 55.0 * sin(e["t"] * agg + e["ph"]) + 18.0 * sin(e["t"] * agg * 2.3)
				e["y"] = e["by"] + 22.0 * sin(e["t"] * 0.55 + e["ph"] * 1.7)
				e["dt"] = 120.0 + 45.0 * sin(e["t"] * 0.25 + e["ph"])
				e["d"] = lerpf(e["d"], e["dt"], minf(dt * 0.9, 1.0))
				if head_t <= 0.0 and e["t"] > 5.0:
					head_t = randf_range(13.0, 17.0) - level * 2.0
					e["mode"] = "away"
			"away":
				e["d"] += 160.0 * dt
				if e["d"] > 480.0:
					e["mode"] = "head"
					e["x"] = px + randf_range(-25.0, 25.0)
					e["y"] = py + randf_range(-10.0, 10.0)
			"head":
				e["d"] -= 175.0 * dt
				e["fire_t"] -= dt
				if e["d"] < 360.0 and e["d"] > 40.0 and e["fire_t"] <= 0.0:
					e["fire_t"] = 0.12
					etracers.append({"x": e["x"], "y": e["y"], "z": camz + e["d"], "t": 0.0})
					m.play("shot", -16.0)
					if absf(e["x"] - px) < 16.0 and absf(e["y"] - py) < 12.0 and randf() < 0.3:
						_hurt(2.5 + level * 0.5)
				if e["d"] < 18.0:
					e["mode"] = "pass"
					e["t2"] = 0.0
			"pass":
				e["t2"] += dt
				if e["t2"] > 1.2:
					e["mode"] = "rear"
					e["d"] = 8.0
					e["x"] = px + randf_range(-30.0, 30.0)
					e["y"] = py + 16.0
					e["bx"] = e["x"]
					e["by"] = e["y"]
					m.play("rpg", -14.0)
			"down":
				e["y"] -= (25.0 + 55.0 * e["t"]) * dt
				e["x"] += e["vx"] * dt
				e["rot"] += 2.8 * dt
				e["d"] -= 20.0 * dt
				e["smoke_t"] -= dt
				if e["smoke_t"] <= 0.0:
					e["smoke_t"] = 0.06
					smoke.append({"x": e["x"], "y": e["y"], "z": camz + e["d"], "s": 7.0, "t": 0.0, "d": 2.2, "c": 0.08})
					fx.append({"x": e["x"], "y": e["y"], "z": camz + e["d"], "s": 6.0, "t": 0.0, "d": 0.25})
				if e["t"] > 2.6 or e["y"] < 8.0:
					_explode_air(e["x"], e["y"], camz + e["d"], 22.0)
					enemies.erase(e)
					continue
		e["vx"] = (e["x"] - ox) / maxf(dt, 0.001)
		e["z"] = camz + e["d"]
		# damaged: smoke trail
		if e["mode"] != "down" and e["hp"] < e["max"] * 0.5:
			e["smoke_t"] -= dt
			if e["smoke_t"] <= 0.0:
				e["smoke_t"] = 0.1
				smoke.append({"x": e["x"], "y": e["y"], "z": e["z"], "s": 5.0, "t": 0.0, "d": 1.8, "c": 0.15})

func _enemy_rect(e: Dictionary) -> Rect2:
	var p := proj(e["x"], e["y"], e["z"])
	if p.z <= 0.0:
		return Rect2()
	var tex: Texture2D = T["spit_front"] if e["mode"] == "head" else T["spit_rear"]
	var w := 11.0 * p.z * ES
	var h := w * tex.get_height() / tex.get_width()
	return Rect2(p.x - w * 0.5, p.y - h * 0.5, w, h)

func _reticle_view() -> Vector2:
	var p := proj(px, py, camz + AHEAD + AIM)
	return Vector2(p.x, p.y)

func _enemy_on_reticle():
	var r := _reticle_view()
	for e in enemies:
		if e["mode"] in ["down", "pass"]:
			continue
		var rr := _enemy_rect(e)
		if rr.size.x > 0.0 and rr.grow_individual(-rr.size.x * 0.12, 4.0, -rr.size.x * 0.12, 4.0).has_point(r):
			return e
	return null

func _fire(e: Dictionary) -> void:
	muzzle = 0.05
	m.play("mg", -7.0)
	var r := _reticle_view()
	tracers.append({"a": _wing(-1), "b": r - Vector2(PAD, PAD), "t": 0.0})
	tracers.append({"a": _wing(1), "b": r - Vector2(PAD, PAD), "t": 0.0})
	e["hp"] -= 1.0
	fx.append({"x": e["x"] + randf_range(-3, 3), "y": e["y"] + randf_range(-1, 1), "z": e["z"], "s": 4.0, "t": 0.0, "d": 0.12})
	if e["hp"] <= 0.0 and e["mode"] != "down":
		e["mode"] = "down"
		e["t"] = 0.0
		e["vx"] = randf_range(-12.0, 12.0)
		m.play("boom", -6.0)
		_banner(L("أسقطت طيارة!", "Fighter down!"))

func _flak(dt: float, interval: float) -> void:
	flak_t -= dt
	if flak_t > 0.0:
		return
	flak_t = maxf(interval, 0.25) * randf_range(0.6, 1.3)
	var f := {"x": px + randf_range(-75.0, 75.0), "y": py + randf_range(-35.0, 35.0), "z": camz + randf_range(160.0, 420.0), "t": 0.0, "hit": false}
	flak.append(f)
	fx.append({"x": f["x"], "y": f["y"], "z": f["z"], "s": 16.0, "t": 0.0, "d": 0.35})
	smoke.append({"x": f["x"], "y": f["y"], "z": f["z"], "s": 14.0, "t": 0.0, "d": 3.5, "c": 0.06, "still": true})
	m.play("boom", -18.0)

func drop_bomb() -> void:
	if bombs <= 0 or not running:
		return
	bombs -= 1
	bombs_air.append({"x": px, "y": py - 3.0, "z": camz + AHEAD, "vy": 0.0, "t": 0.0})
	m.play("click", -4.0)

func _update_bombs(dt: float) -> void:
	for b in bombs_air.duplicate():
		b["t"] += dt
		b["z"] += SPEED * dt
		b["vy"] -= GRAV * dt
		b["y"] += b["vy"] * dt
		if b["y"] <= 0.0:
			bombs_air.erase(b)
			_explode_ground(b["x"], b["z"], 1.0)
			if target_alive and tz < 1e8:
				var dist := Vector2(b["x"] - tx, b["z"] - tz).length()
				if dist < 42.0:
					target_alive = false
					target_t = 0.0
					_explode_ground(tx, tz, 2.4)
					_explode_ground(tx + 20.0, tz - 15.0, 1.6)
					shake = 1.0
				else:
					_banner(L("القنبلة جت بعيد %d م!", "Missed by %d m!") % int(dist))

func _explode_ground(x: float, z: float, s: float) -> void:
	ground_fx.append({"x": x, "z": z, "t": 0.0, "s": s})
	m.play("boom", -2.0)

func _explode_air(x: float, y: float, z: float, s: float) -> void:
	fx.append({"x": x, "y": y, "z": z, "s": s, "t": 0.0, "d": 0.8})
	smoke.append({"x": x, "y": y, "z": z, "s": s * 1.2, "t": 0.0, "d": 3.0, "c": 0.07})
	m.play("boom", -3.0)

func _hurt(d: float) -> void:
	health -= d
	hurt_a = minf(hurt_a + d / 12.0, 1.0)
	m.play("hurt", -8.0)
	if health <= 0.0 and running:
		health = 0.0
		_explode_air(px, py, camz + AHEAD + 4.0, 20.0)
		_fail(L("طيارتك اتضربت", "Your plane was shot down"))

func _fail(sub: String) -> void:
	running = false
	end_title.text = L("فشلت المهمة", "Mission Failed")
	end_sub.text = sub
	end_next.visible = false
	end_p.visible = true
	move_child(end_p, get_child_count() - 1)

func _win() -> void:
	running = false
	if level >= m.best_l:
		m.best_l = mini(level + 1, 3)
		m._save()
	end_title.text = L("نجحت المهمة!", "Mission Complete!")
	end_sub.text = L("دمرت الهدف ورجعت بسلام — المستوى %d", "Target destroyed and back safely — level %d") % level
	end_next.visible = level < 3
	if level >= 3:
		end_sub.text = L("أكملت معركة لندن بالكامل!", "You completed the Battle of London!")
	end_p.visible = true
	move_child(end_p, get_child_count() - 1)
	if not m.rated and not m.rate_shown:
		m.rate_shown = true
		m.rate_p.visible = true
		m.move_child(m.rate_p, m.get_child_count() - 1)

func _update_fx(dt: float) -> void:
	for arr in [fx, smoke]:
		for f in arr.duplicate():
			f["t"] += dt
			if f["t"] >= f["d"]:
				arr.erase(f)
	for s in smoke:
		if not s.has("still"):
			s["y"] += 3.0 * dt
	for arr2 in [tracers, etracers]:
		for tr in arr2.duplicate():
			tr["t"] += dt
			if tr["t"] > 0.09:
				arr2.erase(tr)
	for g in ground_fx.duplicate():
		g["t"] += dt
	if not target_alive and tz < 1e8 and running:
		# burning target: rising smoke column
		if randf() < dt * 10.0:
			smoke.append({"x": tx + randf_range(-15, 15), "y": randf_range(5, 30), "z": tz + randf_range(-15, 15), "s": 30.0, "t": 0.0, "d": 4.0, "c": 0.06, "rise": true})
	for s2 in smoke:
		if s2.has("rise"):
			s2["y"] += 14.0 * dt

# ---------------------------------------------------------------- input
func _input(ev: InputEvent) -> void:
	if not running:
		return
	if ev is InputEventScreenTouch:
		_touch(ev.index, ev.position, ev.pressed)
	elif ev is InputEventScreenDrag:
		if ev.index == joy_idx:
			_joy_set(ev.position)
	elif not DisplayServer.is_touchscreen_available():
		if ev is InputEventMouseButton and ev.button_index == MOUSE_BUTTON_LEFT:
			_touch(0, ev.position, ev.pressed)
		elif ev is InputEventMouseMotion and joy_idx == 0:
			_joy_set(ev.position)

func _touch(idx: int, pos: Vector2, pressed: bool) -> void:
	if pressed:
		if pos.distance_to(BOMB_C) < BOMB_R * 1.15:
			drop_bomb()
		elif pos.distance_to(JOY_C) < JOY_R * 1.7:
			joy_idx = idx
			_joy_set(pos)
		elif PAUSE_BTN.grow(8).has_point(pos):
			running = false
			pause_p.visible = true
			move_child(pause_p, get_child_count() - 1)
	elif idx == joy_idx:
		joy_idx = -1
		joy = Vector2.ZERO

func _joy_set(pos: Vector2) -> void:
	var v := (pos - JOY_C) / JOY_R
	if v.length() > 1.0:
		v = v.normalized()
	joy = v if v.length() > 0.12 else Vector2.ZERO

# ---------------------------------------------------------------- drawing
func _draw_air() -> void:
	var boom: Texture2D = T["boom"]
	# ground: target marker and ground explosions
	if tz < 1e8:
		var g := proj(tx, 0.0, tz)
		if g.z > 0.0:
			var r := 40.0 * g.z
			var squash := clampf(camy / maxf(tz - camz, 1.0), 0.06, 1.0)
			var pulse := 0.5 + 0.5 * sin(Time.get_ticks_msec() / 200.0)
			var col := Color(0.95, 0.1, 0.05, 0.9) if target_alive else Color(0.2, 0.15, 0.1, 0.7)
			air.draw_set_transform(Vector2(g.x, g.y), 0.0, Vector2(1.0, squash))
			if target_alive:
				air.draw_circle(Vector2.ZERO, r * (1.0 + pulse * 0.25), Color(0.95, 0.08, 0.03, 0.18))
			air.draw_arc(Vector2.ZERO, r, 0, TAU, 48, col, maxf(3.0 / squash, 3.0), true)
			air.draw_arc(Vector2.ZERO, r * 0.55, 0, TAU, 40, col, maxf(2.0 / squash, 2.0), true)
			air.draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
			if target_alive:
				var top := Vector2(g.x, g.y - 30.0 - pulse * 8.0)
				air.draw_colored_polygon(PackedVector2Array([top, top + Vector2(-14, -22), top + Vector2(14, -22)]), Color(0.95, 0.1, 0.05))
	for gf in ground_fx:
		var gp := proj(gf["x"], 0.0, gf["z"])
		if gp.z <= 0.0:
			continue
		var k: float = clampf(gf["t"] / 1.2, 0.0, 1.0)
		var sz: float = 70.0 * gf["s"] * gp.z * (0.6 + k * 0.6)
		var hgt: float = sz * boom.get_height() / boom.get_width()
		air.draw_texture_rect(boom, Rect2(Vector2(gp.x, gp.y) - Vector2(sz * 0.5, hgt * 0.8), Vector2(sz, hgt)), false, Color(0.12, 0.1, 0.08, 0.85 * (1.0 - k * 0.5)))
	# air objects sorted far to near
	var items: Array = []
	for e in enemies:
		if e["mode"] != "pass":
			items.append([e["z"], 0, e])
	for s in smoke:
		items.append([s["z"], 1, s])
	for b in bombs_air:
		items.append([b["z"], 2, b])
	items.sort_custom(func(a, b): return a[0] > b[0])
	for it in items:
		match it[1]:
			0:
				var e: Dictionary = it[2]
				var rr := _enemy_rect(e)
				if rr.size.x <= 0.0:
					continue
				var tex: Texture2D = T["spit_front"] if e["mode"] == "head" else T["spit_rear"]
				var ang: float = clampf(e["vx"] * 0.012, -0.7, 0.7) + e["rot"]
				var haze := clampf((e["z"] - camz) / 900.0, 0.0, 0.5)
				var c := Color(1, 1, 1).lerp(Color(1.0, 0.82, 0.6), haze)
				air.draw_set_transform(rr.get_center(), ang, Vector2.ONE)
				air.draw_texture_rect(tex, Rect2(-rr.size * 0.5, rr.size), false, c)
				air.draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
			1:
				var s: Dictionary = it[2]
				var p := proj(s["x"], s["y"], s["z"])
				if p.z <= 0.0:
					continue
				var k2: float = s["t"] / s["d"]
				var sz2: float = s["s"] * p.z * (0.7 + k2 * 1.2)
				var hh: float = sz2 * boom.get_height() / boom.get_width()
				air.draw_texture_rect(boom, Rect2(Vector2(p.x, p.y) - Vector2(sz2, hh) * 0.5, Vector2(sz2, hh)), false, Color(s["c"], s["c"], s["c"], 0.75 * (1.0 - k2)))
			2:
				var b: Dictionary = it[2]
				var bp := proj(b["x"], b["y"], b["z"])
				if bp.z <= 0.0:
					continue
				var bw := maxf(1.6 * bp.z * ES, 10.0)
				var bh: float = bw * T["bomb"].get_height() / T["bomb"].get_width()
				air.draw_texture_rect(T["bomb"], Rect2(Vector2(bp.x, bp.y) - Vector2(bw, bh) * 0.5, Vector2(bw, bh)), false)

func _draw_fx() -> void:
	var boom: Texture2D = T["boom"]
	for f in fx:
		var p := proj(f["x"], f["y"], f["z"])
		if p.z <= 0.0:
			continue
		var k: float = f["t"] / f["d"]
		var sz: float = f["s"] * p.z * (0.6 + k * 0.8) * 1.3
		var hh: float = sz * boom.get_height() / boom.get_width()
		fxl.draw_texture_rect(boom, Rect2(Vector2(p.x, p.y) - Vector2(sz, hh) * 0.5, Vector2(sz, hh)), false, Color(1, 1, 1, pow(1.0 - k, 1.3)))
	for gf in ground_fx:
		var gp := proj(gf["x"], 0.0, gf["z"])
		if gp.z <= 0.0 or gf["t"] > 1.0:
			continue
		var k3: float = gf["t"] / 1.0
		var s3: float = 80.0 * gf["s"] * gp.z * (0.5 + k3)
		var h3: float = s3 * boom.get_height() / boom.get_width()
		fxl.draw_texture_rect(boom, Rect2(Vector2(gp.x, gp.y) - Vector2(s3 * 0.5, h3 * 0.85), Vector2(s3, h3)), false, Color(1, 1, 1, 1.0 - k3))
	for et in etracers:
		var a := proj(et["x"], et["y"], et["z"])
		var b := proj(px, py, camz + AHEAD + 6.0)
		if a.z <= 0.0 or b.z <= 0.0:
			continue
		var k4: float = et["t"] / 0.09
		var p1 := Vector2(a.x, a.y).lerp(Vector2(b.x, b.y), clampf(k4 * 1.2 - 0.2, 0.0, 1.0))
		var p2 := Vector2(a.x, a.y).lerp(Vector2(b.x, b.y), clampf(k4 * 1.2 + 0.1, 0.0, 1.0))
		fxl.draw_line(p1, p2, Color(1, 0.55, 0.3, 0.9), 2.5)

func _plane_geom() -> Dictionary:
	var p := proj(px, py, camz + AHEAD)
	var w := 400.0
	var h: float = w * T["stuka"].get_height() / T["stuka"].get_width()
	var c := Vector2(p.x, p.y) - Vector2(PAD, PAD) + Vector2(0, 95)
	return {"c": c, "w": w, "h": h, "ang": bank * 0.55}

func _wing(side: int) -> Vector2:
	var g := _plane_geom()
	return g["c"] + Vector2(side * g["w"] * 0.2, -g["h"] * 0.12).rotated(g["ang"])

func _draw_plane() -> void:
	if health <= 0.0:
		return
	var g := _plane_geom()
	plane_l.draw_set_transform(g["c"], g["ang"], Vector2.ONE)
	plane_l.draw_texture_rect(T["stuka"], Rect2(-g["w"] * 0.5, -g["h"] * 0.5, g["w"], g["h"]), false)
	plane_l.draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)

func _draw_plane_fx() -> void:
	for tr in tracers:
		var k: float = tr["t"] / 0.09
		var a: Vector2 = tr["a"]
		var b: Vector2 = tr["b"]
		plane_fx.draw_line(a.lerp(b, clampf(k * 1.3 - 0.3, 0.0, 1.0)), a.lerp(b, clampf(k * 1.3 + 0.1, 0.0, 1.0)), Color(1, 0.75, 0.35, 0.9), 3.0)
	if muzzle > 0.0:
		var boom: Texture2D = T["boom"]
		for s in [-1, 1]:
			var wp := _wing(s)
			plane_fx.draw_texture_rect(boom, Rect2(wp - Vector2(36, 26), Vector2(72, 52)), false)

func _draw_reticle() -> void:
	if not running and not end_p.visible and not pause_p.visible:
		return
	var r := _reticle_view() - Vector2(PAD, PAD)
	var sz := 150.0
	var c := Color(1, 0.55, 0.45) if firing else Color(1, 1, 1, 0.9)
	ret_l.draw_texture_rect(T["reticle"], Rect2(r - Vector2(sz, sz) * 0.5, Vector2(sz, sz)), false, c)

func _draw_hud() -> void:
	if brief.visible:
		return
	var font: Font = m.font
	# health
	var hb := Rect2(24, 22, 300, 26)
	hud.draw_rect(hb.grow(3), Color(0, 0, 0, 0.6))
	var hc := Color(0.25, 0.8, 0.3) if health > 50 else (Color(0.95, 0.75, 0.15) if health > 25 else Color(0.95, 0.15, 0.1))
	hud.draw_rect(Rect2(hb.position, Vector2(hb.size.x * health / 100.0, hb.size.y)), hc)
	hud.draw_string(font, Vector2(30, 76), L("الصحة %d", "Health %d") % int(health), HORIZONTAL_ALIGNMENT_LEFT, -1, 22, Color(1, 1, 1))
	# bomb button
	var cs := BOMB_R * 2.1
	var ready := bombs > 0 and phase == "city" and target_alive
	hud.draw_texture_rect(T["btn_cannon"], Rect2(BOMB_C - Vector2(cs, cs) * 0.5, Vector2(cs, cs)), false, Color(1, 1, 1) if ready else Color(0.55, 0.55, 0.55, 0.9))
	var lab := L("قنبلة × %d", "BOMB × %d") % bombs
	var cw := font.get_string_size(lab, HORIZONTAL_ALIGNMENT_LEFT, -1, 24).x
	var cb := Rect2(BOMB_C + Vector2(-cw * 0.5 - 12, cs * 0.5 - 18), Vector2(cw + 24, 36))
	hud.draw_rect(cb, Color(0.12, 0.1, 0.07, 0.92))
	hud.draw_rect(cb, Color(0.8, 0.62, 0.3), false, 2.0)
	hud.draw_string(font, cb.position + Vector2(12, 27), lab, HORIZONTAL_ALIGNMENT_LEFT, -1, 24, Color(1, 0.88, 0.55))
	# arrow pad
	var ds := JOY_R * 2.15
	hud.draw_texture_rect(T["btn_dpad"], Rect2(JOY_C + joy * 7.0 - Vector2(ds, ds) * 0.5, Vector2(ds, ds)), false, Color(1.15, 1.1, 1.0) if joy != Vector2.ZERO else Color(1, 1, 1, 0.95))
	# pause
	hud.draw_rect(PAUSE_BTN, Color(0, 0, 0, 0.45))
	hud.draw_rect(Rect2(PAUSE_BTN.position + Vector2(24, 14), Vector2(8, 28)), Color(1, 0.92, 0.7))
	hud.draw_rect(Rect2(PAUSE_BTN.position + Vector2(40, 14), Vector2(8, 28)), Color(1, 0.92, 0.7))
	# off-screen target arrow while approaching
	if phase == "city" and target_alive:
		var g := proj(tx, 0.0, tz)
		if g.z > 0.0:
			var sp := Vector2(g.x, g.y) - Vector2(PAD, PAD)
			if sp.y > H - 40 or sp.x < 40 or sp.x > W - 40:
				var cpos := Vector2(clampf(sp.x, 60, W - 60), clampf(sp.y, 120, H - 60))
				hud.draw_circle(cpos, 16, Color(0.95, 0.1, 0.05, 0.85))
